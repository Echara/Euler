package com.spring.test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ioc.component.MyComponent;
import com.ioc.component.OrderAction;
import com.ioc.component.OrderDao;
import com.ioc.component.OrderService;
import com.ioc.component.UserAction;
import com.ioc.service.BookService;

public class IocTest {

	private ApplicationContext applicationContext;

	@Before
	public void init() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
	}

	@Test
	public void test01() {
		//MyComponent mc = applicationContext.getBean(MyComponent.class);
		OrderAction oa = applicationContext.getBean(OrderAction.class);
		OrderService os = applicationContext.getBean(OrderService.class);
		OrderDao od = applicationContext.getBean(OrderDao.class);
		//System.out.println("test01 : " + mc);
		System.out.println("test01 : " + oa);
		System.out.println("test01 : " + os);
		System.out.println("test01 : " + od);
	}

	@Test
	public void test02() {
		MyComponent mc = applicationContext.getBean(MyComponent.class);
		//OrderAction oa = applicationContext.getBean(OrderAction.class);
		OrderService os = applicationContext.getBean(OrderService.class);
		OrderDao od = applicationContext.getBean(OrderDao.class);
		System.out.println("test02 : " + mc);
		//System.out.println("test02 : " + oa);
		System.out.println("test02 : " + os);
		System.out.println("test02 : " + od);
	}

	@Test
	public void test03() {
		MyComponent mc10 = (MyComponent) applicationContext.getBean("hello");
		//MyComponent mc11 = (MyComponent) applicationContext.getBean("myComponent");
		MyComponent mc20 = (MyComponent) applicationContext.getBean("myComponent2");
		System.out.println("test03 : " + mc10);
		//System.out.println("test03 : " + mc11);
		System.out.println("test03 : " + mc20);
	}

	@Test
	public void test04() {
		MyComponent mc = applicationContext.getBean(MyComponent.class);
		OrderAction oa = applicationContext.getBean(OrderAction.class);
		OrderService os = applicationContext.getBean(OrderService.class);
		OrderDao od = applicationContext.getBean(OrderDao.class);
		System.out.println("test04 : " + mc);
		System.out.println("test04 : " + oa);
		System.out.println("test04 : " + os);
		System.out.println("test04 : " + od);
	}

	@Test
	public void test05() {
		UserAction userAction = applicationContext.getBean(UserAction.class);
		userAction.testing();
	}

	@Test
	public void test06() {
		BookService bookService = applicationContext.getBean(BookService.class);
		//BookService bookService = new BookService();
		bookService.save();
	}
}
