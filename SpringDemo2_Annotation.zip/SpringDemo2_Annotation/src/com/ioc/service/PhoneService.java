package com.ioc.service;

import org.springframework.stereotype.Service;

import com.ioc.mybean.Phone;

@Service
public class PhoneService extends BaseService<Phone>{

}
