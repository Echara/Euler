package com.ioc.service;

import org.springframework.stereotype.Service;

import com.ioc.mybean.Book;

@Service
public class BookService extends BaseService<Book>{

}
