package com.ioc.repository;

import org.springframework.stereotype.Repository;

import com.ioc.mybean.Book;

@Repository
public class BookDao extends BaseDao<Book> {

	@Override
	public void save() {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("BookDao save");
	}

}
