package com.ioc.repository;

public abstract class BaseDao<T> {

	public abstract void save();

}
