package com.ioc.mybean;

public class Phone {

}
