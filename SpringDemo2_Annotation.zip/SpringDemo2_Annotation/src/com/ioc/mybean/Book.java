package com.ioc.mybean;

public class Book {

}
