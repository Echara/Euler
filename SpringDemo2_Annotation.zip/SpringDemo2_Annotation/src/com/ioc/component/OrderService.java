package com.ioc.component;

import org.springframework.stereotype.Service;

@Service
public class OrderService {

}
