package com.ioc.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

@Controller
public class UserAction {

	@Autowired
	@Qualifier("userService02")
	private UserService userService;

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void testing() {
		this.userService.hello();
	}

	public void testing2(@Qualifier("userService02") UserService userService100) {
		userService100.hello();
	}
}