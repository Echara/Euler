package com.ioc.component;

import org.springframework.stereotype.Repository;

@Repository
public class OrderDao {

}
