package com.ioc.component;

import org.springframework.stereotype.Component;

@Component
//@Component(value="hello")
public class MyComponent {

}
