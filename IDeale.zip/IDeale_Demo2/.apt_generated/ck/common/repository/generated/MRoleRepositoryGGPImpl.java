package ck.common.repository.generated;

/** */
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T10:31:49.836+0900")
public class MRoleRepositoryGGPImpl extends org.seasar.doma.internal.jdbc.dao.AbstractDao implements ck.common.repository.generated.MRoleRepositoryGGP {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    private static final java.lang.reflect.Method __method0 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MRoleRepositoryGGP.class, "selectById", java.lang.Long.class);

    private static final java.lang.reflect.Method __method1 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MRoleRepositoryGGP.class, "selectByIdAndVersion", java.lang.Long.class, java.lang.Long.class);

    private static final java.lang.reflect.Method __method2 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MRoleRepositoryGGP.class, "insert", ck.common.entity.MRole.class);

    private static final java.lang.reflect.Method __method3 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MRoleRepositoryGGP.class, "update", ck.common.entity.MRole.class);

    private static final java.lang.reflect.Method __method4 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MRoleRepositoryGGP.class, "delete", ck.common.entity.MRole.class);

    /**
     * @param config the config
     */
    public MRoleRepositoryGGPImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

    @Override
    public ck.common.entity.MRole selectById(java.lang.Long pk) {
        entering("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectById", pk);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method0);
            __query.setMethod(__method0);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/generated/MRoleRepositoryGGP/selectById.sql");
            __query.setEntityType(ck.common.entity._MRole.getSingletonInternal());
            __query.addParameter("pk", java.lang.Long.class, pk);
            __query.setCallerClassName("ck.common.repository.generated.MRoleRepositoryGGPImpl");
            __query.setCallerMethodName("selectById");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<ck.common.entity.MRole> __command = getCommandImplementors().createSelectCommand(__method0, __query, new org.seasar.doma.internal.jdbc.command.EntitySingleResultHandler<ck.common.entity.MRole>(ck.common.entity._MRole.getSingletonInternal()));
            ck.common.entity.MRole __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectById", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectById", __e);
            throw __e;
        }
    }

    @Override
    public ck.common.entity.MRole selectByIdAndVersion(java.lang.Long pk, java.lang.Long versionNo) {
        entering("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectByIdAndVersion", pk, versionNo);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method1);
            __query.setMethod(__method1);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/generated/MRoleRepositoryGGP/selectByIdAndVersion.sql");
            __query.setEntityType(ck.common.entity._MRole.getSingletonInternal());
            __query.addParameter("pk", java.lang.Long.class, pk);
            __query.addParameter("versionNo", java.lang.Long.class, versionNo);
            __query.setCallerClassName("ck.common.repository.generated.MRoleRepositoryGGPImpl");
            __query.setCallerMethodName("selectByIdAndVersion");
            __query.setResultEnsured(true);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<ck.common.entity.MRole> __command = getCommandImplementors().createSelectCommand(__method1, __query, new org.seasar.doma.internal.jdbc.command.EntitySingleResultHandler<ck.common.entity.MRole>(ck.common.entity._MRole.getSingletonInternal()));
            ck.common.entity.MRole __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectByIdAndVersion", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MRoleRepositoryGGPImpl", "selectByIdAndVersion", __e);
            throw __e;
        }
    }

    @Override
    public int insert(ck.common.entity.MRole entity) {
        entering("ck.common.repository.generated.MRoleRepositoryGGPImpl", "insert", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoInsertQuery<ck.common.entity.MRole> __query = getQueryImplementors().createAutoInsertQuery(__method2, ck.common.entity._MRole.getSingletonInternal());
            __query.setMethod(__method2);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MRoleRepositoryGGPImpl");
            __query.setCallerMethodName("insert");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setNullExcluded(false);
            __query.setIncludedPropertyNames();
            __query.setExcludedPropertyNames();
            __query.prepare();
            org.seasar.doma.jdbc.command.InsertCommand __command = getCommandImplementors().createInsertCommand(__method2, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MRoleRepositoryGGPImpl", "insert", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MRoleRepositoryGGPImpl", "insert", __e);
            throw __e;
        }
    }

    @Override
    public int update(ck.common.entity.MRole entity) {
        entering("ck.common.repository.generated.MRoleRepositoryGGPImpl", "update", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoUpdateQuery<ck.common.entity.MRole> __query = getQueryImplementors().createAutoUpdateQuery(__method3, ck.common.entity._MRole.getSingletonInternal());
            __query.setMethod(__method3);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MRoleRepositoryGGPImpl");
            __query.setCallerMethodName("update");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setNullExcluded(false);
            __query.setVersionIgnored(false);
            __query.setIncludedPropertyNames();
            __query.setExcludedPropertyNames();
            __query.setUnchangedPropertyIncluded(false);
            __query.setOptimisticLockExceptionSuppressed(false);
            __query.prepare();
            org.seasar.doma.jdbc.command.UpdateCommand __command = getCommandImplementors().createUpdateCommand(__method3, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MRoleRepositoryGGPImpl", "update", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MRoleRepositoryGGPImpl", "update", __e);
            throw __e;
        }
    }

    @Override
    public int delete(ck.common.entity.MRole entity) {
        entering("ck.common.repository.generated.MRoleRepositoryGGPImpl", "delete", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoDeleteQuery<ck.common.entity.MRole> __query = getQueryImplementors().createAutoDeleteQuery(__method4, ck.common.entity._MRole.getSingletonInternal());
            __query.setMethod(__method4);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MRoleRepositoryGGPImpl");
            __query.setCallerMethodName("delete");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setVersionIgnored(false);
            __query.setOptimisticLockExceptionSuppressed(false);
            __query.prepare();
            org.seasar.doma.jdbc.command.DeleteCommand __command = getCommandImplementors().createDeleteCommand(__method4, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MRoleRepositoryGGPImpl", "delete", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MRoleRepositoryGGPImpl", "delete", __e);
            throw __e;
        }
    }

}
