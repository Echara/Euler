package ck.common.repository.generated;

/** */
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T19:31:55.416+0900")
public class MyTableRepositoryGGPImpl extends org.seasar.doma.internal.jdbc.dao.AbstractDao implements ck.common.repository.generated.MyTableRepositoryGGP {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    /**
     * @param config the config
     */
    public MyTableRepositoryGGPImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

}
