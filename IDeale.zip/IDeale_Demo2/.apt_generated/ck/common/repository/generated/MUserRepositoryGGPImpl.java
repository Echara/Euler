package ck.common.repository.generated;

/** */
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T17:53:22.557+0900")
public class MUserRepositoryGGPImpl extends org.seasar.doma.internal.jdbc.dao.AbstractDao implements ck.common.repository.generated.MUserRepositoryGGP {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    private static final java.lang.reflect.Method __method0 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MUserRepositoryGGP.class, "selectById", java.lang.Long.class);

    private static final java.lang.reflect.Method __method1 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MUserRepositoryGGP.class, "selectByIdAndVersion", java.lang.Long.class, java.lang.Long.class);

    private static final java.lang.reflect.Method __method2 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MUserRepositoryGGP.class, "insert", ck.common.entity.MUser.class);

    private static final java.lang.reflect.Method __method3 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MUserRepositoryGGP.class, "update", ck.common.entity.MUser.class);

    private static final java.lang.reflect.Method __method4 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.generated.MUserRepositoryGGP.class, "delete", ck.common.entity.MUser.class);

    /**
     * @param config the config
     */
    public MUserRepositoryGGPImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

    @Override
    public ck.common.entity.MUser selectById(java.lang.Long pk) {
        entering("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectById", pk);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method0);
            __query.setMethod(__method0);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/generated/MUserRepositoryGGP/selectById.sql");
            __query.setEntityType(ck.common.entity._MUser.getSingletonInternal());
            __query.addParameter("pk", java.lang.Long.class, pk);
            __query.setCallerClassName("ck.common.repository.generated.MUserRepositoryGGPImpl");
            __query.setCallerMethodName("selectById");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<ck.common.entity.MUser> __command = getCommandImplementors().createSelectCommand(__method0, __query, new org.seasar.doma.internal.jdbc.command.EntitySingleResultHandler<ck.common.entity.MUser>(ck.common.entity._MUser.getSingletonInternal()));
            ck.common.entity.MUser __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectById", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectById", __e);
            throw __e;
        }
    }

    @Override
    public ck.common.entity.MUser selectByIdAndVersion(java.lang.Long pk, java.lang.Long versionNo) {
        entering("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectByIdAndVersion", pk, versionNo);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method1);
            __query.setMethod(__method1);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/generated/MUserRepositoryGGP/selectByIdAndVersion.sql");
            __query.setEntityType(ck.common.entity._MUser.getSingletonInternal());
            __query.addParameter("pk", java.lang.Long.class, pk);
            __query.addParameter("versionNo", java.lang.Long.class, versionNo);
            __query.setCallerClassName("ck.common.repository.generated.MUserRepositoryGGPImpl");
            __query.setCallerMethodName("selectByIdAndVersion");
            __query.setResultEnsured(true);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<ck.common.entity.MUser> __command = getCommandImplementors().createSelectCommand(__method1, __query, new org.seasar.doma.internal.jdbc.command.EntitySingleResultHandler<ck.common.entity.MUser>(ck.common.entity._MUser.getSingletonInternal()));
            ck.common.entity.MUser __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectByIdAndVersion", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MUserRepositoryGGPImpl", "selectByIdAndVersion", __e);
            throw __e;
        }
    }

    @Override
    public int insert(ck.common.entity.MUser entity) {
        entering("ck.common.repository.generated.MUserRepositoryGGPImpl", "insert", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoInsertQuery<ck.common.entity.MUser> __query = getQueryImplementors().createAutoInsertQuery(__method2, ck.common.entity._MUser.getSingletonInternal());
            __query.setMethod(__method2);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MUserRepositoryGGPImpl");
            __query.setCallerMethodName("insert");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setNullExcluded(false);
            __query.setIncludedPropertyNames();
            __query.setExcludedPropertyNames();
            __query.prepare();
            org.seasar.doma.jdbc.command.InsertCommand __command = getCommandImplementors().createInsertCommand(__method2, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MUserRepositoryGGPImpl", "insert", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MUserRepositoryGGPImpl", "insert", __e);
            throw __e;
        }
    }

    @Override
    public int update(ck.common.entity.MUser entity) {
        entering("ck.common.repository.generated.MUserRepositoryGGPImpl", "update", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoUpdateQuery<ck.common.entity.MUser> __query = getQueryImplementors().createAutoUpdateQuery(__method3, ck.common.entity._MUser.getSingletonInternal());
            __query.setMethod(__method3);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MUserRepositoryGGPImpl");
            __query.setCallerMethodName("update");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setNullExcluded(false);
            __query.setVersionIgnored(false);
            __query.setIncludedPropertyNames();
            __query.setExcludedPropertyNames();
            __query.setUnchangedPropertyIncluded(false);
            __query.setOptimisticLockExceptionSuppressed(false);
            __query.prepare();
            org.seasar.doma.jdbc.command.UpdateCommand __command = getCommandImplementors().createUpdateCommand(__method3, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MUserRepositoryGGPImpl", "update", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MUserRepositoryGGPImpl", "update", __e);
            throw __e;
        }
    }

    @Override
    public int delete(ck.common.entity.MUser entity) {
        entering("ck.common.repository.generated.MUserRepositoryGGPImpl", "delete", entity);
        try {
            if (entity == null) {
                throw new org.seasar.doma.DomaNullPointerException("entity");
            }
            org.seasar.doma.jdbc.query.AutoDeleteQuery<ck.common.entity.MUser> __query = getQueryImplementors().createAutoDeleteQuery(__method4, ck.common.entity._MUser.getSingletonInternal());
            __query.setMethod(__method4);
            __query.setConfig(__config);
            __query.setEntity(entity);
            __query.setCallerClassName("ck.common.repository.generated.MUserRepositoryGGPImpl");
            __query.setCallerMethodName("delete");
            __query.setQueryTimeout(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.setVersionIgnored(false);
            __query.setOptimisticLockExceptionSuppressed(false);
            __query.prepare();
            org.seasar.doma.jdbc.command.DeleteCommand __command = getCommandImplementors().createDeleteCommand(__method4, __query);
            int __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.generated.MUserRepositoryGGPImpl", "delete", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.generated.MUserRepositoryGGPImpl", "delete", __e);
            throw __e;
        }
    }

}
