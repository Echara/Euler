package ck.common.repository;

/** */
@org.springframework.stereotype.Component()
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T10:31:49.812+0900")
public class RUserRoleRepositoryImpl extends ck.common.repository.generated.RUserRoleRepositoryGGPImpl implements ck.common.repository.RUserRoleRepository {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    /**
     * @param config the config
     */
    @org.springframework.beans.factory.annotation.Autowired()
    public RUserRoleRepositoryImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

}
