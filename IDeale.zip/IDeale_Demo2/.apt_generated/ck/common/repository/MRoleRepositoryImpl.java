package ck.common.repository;

/** */
@org.springframework.stereotype.Component()
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T10:31:49.870+0900")
public class MRoleRepositoryImpl extends ck.common.repository.generated.MRoleRepositoryGGPImpl implements ck.common.repository.MRoleRepository {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    private static final java.lang.reflect.Method __method0 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.MRoleRepository.class, "selectAll");

    private static final java.lang.reflect.Method __method1 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.MRoleRepository.class, "selectByUserId", java.lang.String.class);

    private static final java.lang.reflect.Method __method2 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.MRoleRepository.class, "selectAllToMap", java.util.function.Function.class);

    /**
     * @param config the config
     */
    @org.springframework.beans.factory.annotation.Autowired()
    public MRoleRepositoryImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

    @Override
    public java.util.List<ck.common.entity.MRole> selectAll() {
        entering("ck.common.repository.MRoleRepositoryImpl", "selectAll");
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method0);
            __query.setMethod(__method0);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/MRoleRepository/selectAll.sql");
            __query.setEntityType(ck.common.entity._MRole.getSingletonInternal());
            __query.setCallerClassName("ck.common.repository.MRoleRepositoryImpl");
            __query.setCallerMethodName("selectAll");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<java.util.List<ck.common.entity.MRole>> __command = getCommandImplementors().createSelectCommand(__method0, __query, new org.seasar.doma.internal.jdbc.command.EntityResultListHandler<ck.common.entity.MRole>(ck.common.entity._MRole.getSingletonInternal()));
            java.util.List<ck.common.entity.MRole> __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.MRoleRepositoryImpl", "selectAll", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.MRoleRepositoryImpl", "selectAll", __e);
            throw __e;
        }
    }

    @Override
    public java.util.List<ck.common.entity.MRole> selectByUserId(java.lang.String userId) {
        entering("ck.common.repository.MRoleRepositoryImpl", "selectByUserId", userId);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method1);
            __query.setMethod(__method1);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/MRoleRepository/selectByUserId.sql");
            __query.setEntityType(ck.common.entity._MRole.getSingletonInternal());
            __query.addParameter("userId", java.lang.String.class, userId);
            __query.setCallerClassName("ck.common.repository.MRoleRepositoryImpl");
            __query.setCallerMethodName("selectByUserId");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<java.util.List<ck.common.entity.MRole>> __command = getCommandImplementors().createSelectCommand(__method1, __query, new org.seasar.doma.internal.jdbc.command.EntityResultListHandler<ck.common.entity.MRole>(ck.common.entity._MRole.getSingletonInternal()));
            java.util.List<ck.common.entity.MRole> __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.MRoleRepositoryImpl", "selectByUserId", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.MRoleRepositoryImpl", "selectByUserId", __e);
            throw __e;
        }
    }

    @Override
    public java.util.Map<java.lang.String, ck.common.entity.MRole> selectAllToMap(java.util.function.Function<java.util.stream.Stream<ck.common.entity.MRole>, java.util.Map<java.lang.String, ck.common.entity.MRole>> mapper) {
        entering("ck.common.repository.MRoleRepositoryImpl", "selectAllToMap", mapper);
        try {
            if (mapper == null) {
                throw new org.seasar.doma.DomaNullPointerException("mapper");
            }
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method2);
            __query.setMethod(__method2);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/MRoleRepository/selectAllToMap.sql");
            __query.setEntityType(ck.common.entity._MRole.getSingletonInternal());
            __query.setCallerClassName("ck.common.repository.MRoleRepositoryImpl");
            __query.setCallerMethodName("selectAllToMap");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<java.util.Map<java.lang.String, ck.common.entity.MRole>> __command = getCommandImplementors().createSelectCommand(__method2, __query, new org.seasar.doma.internal.jdbc.command.EntityStreamHandler<ck.common.entity.MRole, java.util.Map<java.lang.String, ck.common.entity.MRole>>(ck.common.entity._MRole.getSingletonInternal(), mapper));
            java.util.Map<java.lang.String, ck.common.entity.MRole> __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.MRoleRepositoryImpl", "selectAllToMap", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.MRoleRepositoryImpl", "selectAllToMap", __e);
            throw __e;
        }
    }

}
