package ck.common.repository;

/** */
@org.springframework.stereotype.Component()
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T17:57:15.269+0900")
public class MUserRepositoryImpl extends ck.common.repository.generated.MUserRepositoryGGPImpl implements ck.common.repository.MUserRepository {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    private static final java.lang.reflect.Method __method0 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.MUserRepository.class, "selectByUserId", java.lang.String.class);

    private static final java.lang.reflect.Method __method1 = org.seasar.doma.internal.jdbc.dao.AbstractDao.getDeclaredMethod(ck.common.repository.MUserRepository.class, "selectAll");

    /**
     * @param config the config
     */
    @org.springframework.beans.factory.annotation.Autowired()
    public MUserRepositoryImpl(org.seasar.doma.jdbc.Config config) {
        super(config);
    }

    @Override
    public ck.common.entity.MUser selectByUserId(java.lang.String userId) {
        entering("ck.common.repository.MUserRepositoryImpl", "selectByUserId", userId);
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method0);
            __query.setMethod(__method0);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/MUserRepository/selectByUserId.sql");
            __query.setEntityType(ck.common.entity._MUser.getSingletonInternal());
            __query.addParameter("userId", java.lang.String.class, userId);
            __query.setCallerClassName("ck.common.repository.MUserRepositoryImpl");
            __query.setCallerMethodName("selectByUserId");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<ck.common.entity.MUser> __command = getCommandImplementors().createSelectCommand(__method0, __query, new org.seasar.doma.internal.jdbc.command.EntitySingleResultHandler<ck.common.entity.MUser>(ck.common.entity._MUser.getSingletonInternal()));
            ck.common.entity.MUser __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.MUserRepositoryImpl", "selectByUserId", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.MUserRepositoryImpl", "selectByUserId", __e);
            throw __e;
        }
    }

    @Override
    public java.util.List<ck.common.entity.MUser> selectAll() {
        entering("ck.common.repository.MUserRepositoryImpl", "selectAll");
        try {
            org.seasar.doma.jdbc.query.SqlFileSelectQuery __query = getQueryImplementors().createSqlFileSelectQuery(__method1);
            __query.setMethod(__method1);
            __query.setConfig(__config);
            __query.setSqlFilePath("META-INF/ck/common/repository/MUserRepository/selectAll.sql");
            __query.setEntityType(ck.common.entity._MUser.getSingletonInternal());
            __query.setCallerClassName("ck.common.repository.MUserRepositoryImpl");
            __query.setCallerMethodName("selectAll");
            __query.setResultEnsured(false);
            __query.setResultMappingEnsured(false);
            __query.setFetchType(org.seasar.doma.FetchType.LAZY);
            __query.setQueryTimeout(-1);
            __query.setMaxRows(-1);
            __query.setFetchSize(-1);
            __query.setSqlLogType(org.seasar.doma.jdbc.SqlLogType.FORMATTED);
            __query.prepare();
            org.seasar.doma.jdbc.command.SelectCommand<java.util.List<ck.common.entity.MUser>> __command = getCommandImplementors().createSelectCommand(__method1, __query, new org.seasar.doma.internal.jdbc.command.EntityResultListHandler<ck.common.entity.MUser>(ck.common.entity._MUser.getSingletonInternal()));
            java.util.List<ck.common.entity.MUser> __result = __command.execute();
            __query.complete();
            exiting("ck.common.repository.MUserRepositoryImpl", "selectAll", __result);
            return __result;
        } catch (java.lang.RuntimeException __e) {
            throwing("ck.common.repository.MUserRepositoryImpl", "selectAll", __e);
            throw __e;
        }
    }

}
