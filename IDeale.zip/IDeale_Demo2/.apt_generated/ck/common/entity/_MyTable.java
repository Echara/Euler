package ck.common.entity;

/** */
@javax.annotation.Generated(value = { "Doma", "2.9.0" }, date = "2018-12-27T19:11:48.225+0900")
public final class _MyTable extends org.seasar.doma.jdbc.entity.AbstractEntityType<ck.common.entity.MyTable> {

    static {
        org.seasar.doma.internal.Artifact.validateVersion("2.9.0");
    }

    private static final _MyTable __singleton = new _MyTable();

    private final org.seasar.doma.jdbc.entity.NamingType __namingType = org.seasar.doma.jdbc.entity.NamingType.SNAKE_LOWER_CASE;

    private final org.seasar.doma.jdbc.id.BuiltinIdentityIdGenerator __idGenerator = new org.seasar.doma.jdbc.id.BuiltinIdentityIdGenerator();

    /** the createdDateTime */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, java.time.LocalDateTime, Object> $createdDateTime = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.time.LocalDateTime.class, java.time.LocalDateTime.class, () -> new org.seasar.doma.wrapper.LocalDateTimeWrapper(), jp.co.idnet.ideale.persistence.doma.entity._CommonFieldEntity.getSingletonInternal().$createdDateTime, null, "createdDateTime", "", __namingType, true, true, false);

    /** the createdUserId */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, java.lang.String, Object> $createdUserId = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.lang.String.class, java.lang.String.class, () -> new org.seasar.doma.wrapper.StringWrapper(), jp.co.idnet.ideale.persistence.doma.entity._CommonFieldEntity.getSingletonInternal().$createdUserId, null, "createdUserId", "", __namingType, true, true, false);

    /** the updatedDateTime */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, java.time.LocalDateTime, Object> $updatedDateTime = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.time.LocalDateTime.class, java.time.LocalDateTime.class, () -> new org.seasar.doma.wrapper.LocalDateTimeWrapper(), jp.co.idnet.ideale.persistence.doma.entity._CommonFieldEntity.getSingletonInternal().$updatedDateTime, null, "updatedDateTime", "", __namingType, true, true, false);

    /** the updatedUserId */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, java.lang.String, Object> $updatedUserId = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.lang.String.class, java.lang.String.class, () -> new org.seasar.doma.wrapper.StringWrapper(), jp.co.idnet.ideale.persistence.doma.entity._CommonFieldEntity.getSingletonInternal().$updatedUserId, null, "updatedUserId", "", __namingType, true, true, false);

    /** the versionNo */
    public final org.seasar.doma.jdbc.entity.VersionPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, java.lang.Long, Object> $versionNo = new org.seasar.doma.jdbc.entity.VersionPropertyType<>(ck.common.entity.MyTable.class,  java.lang.Long.class, java.lang.Long.class, () -> new org.seasar.doma.wrapper.LongWrapper(), jp.co.idnet.ideale.persistence.doma.entity._CommonFieldEntity.getSingletonInternal().$versionNo, null, "versionNo", "", __namingType, false);

    /** the id */
    public final org.seasar.doma.jdbc.entity.GeneratedIdPropertyType<java.lang.Object, ck.common.entity.MyTable, java.lang.Integer, Object> $id = new org.seasar.doma.jdbc.entity.GeneratedIdPropertyType<>(ck.common.entity.MyTable.class, java.lang.Integer.class, java.lang.Integer.class, () -> new org.seasar.doma.wrapper.IntegerWrapper(), null, null, "id", "id", __namingType, false, __idGenerator);

    /** the name */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<java.lang.Object, ck.common.entity.MyTable, java.lang.String, Object> $name = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.lang.String.class, java.lang.String.class, () -> new org.seasar.doma.wrapper.StringWrapper(), null, null, "name", "name", __namingType, true, true, false);

    /** the dep */
    public final org.seasar.doma.jdbc.entity.DefaultPropertyType<java.lang.Object, ck.common.entity.MyTable, java.lang.Integer, Object> $dep = new org.seasar.doma.jdbc.entity.DefaultPropertyType<>(ck.common.entity.MyTable.class, java.lang.Integer.class, java.lang.Integer.class, () -> new org.seasar.doma.wrapper.IntegerWrapper(), null, null, "dep", "dep", __namingType, true, true, false);

    private final java.util.function.Supplier<jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener<ck.common.entity.MyTable>> __listenerSupplier;

    private final boolean __immutable;

    private final String __catalogName;

    private final String __schemaName;

    private final String __tableName;

    private final boolean __isQuoteRequired;

    private final String __name;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __idPropertyTypes;

    private final java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __entityPropertyTypes;

    private final java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __entityPropertyTypeMap;

    private _MyTable() {
        __listenerSupplier = () -> ListenerHolder.listener;
        __immutable = false;
        __name = "MyTable";
        __catalogName = "";
        __schemaName = "";
        __tableName = "My_Table";
        __isQuoteRequired = false;
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __idList = new java.util.ArrayList<>();
        java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __list = new java.util.ArrayList<>(8);
        java.util.Map<String, org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> __map = new java.util.HashMap<>(8);
        __list.add($createdDateTime);
        __map.put("createdDateTime", $createdDateTime);
        __list.add($createdUserId);
        __map.put("createdUserId", $createdUserId);
        __list.add($updatedDateTime);
        __map.put("updatedDateTime", $updatedDateTime);
        __list.add($updatedUserId);
        __map.put("updatedUserId", $updatedUserId);
        __list.add($versionNo);
        __map.put("versionNo", $versionNo);
        __idList.add($id);
        __list.add($id);
        __map.put("id", $id);
        __list.add($name);
        __map.put("name", $name);
        __list.add($dep);
        __map.put("dep", $dep);
        __idPropertyTypes = java.util.Collections.unmodifiableList(__idList);
        __entityPropertyTypes = java.util.Collections.unmodifiableList(__list);
        __entityPropertyTypeMap = java.util.Collections.unmodifiableMap(__map);
    }

    @Override
    public org.seasar.doma.jdbc.entity.NamingType getNamingType() {
        return __namingType;
    }

    @Override
    public boolean isImmutable() {
        return __immutable;
    }

    @Override
    public String getName() {
        return __name;
    }

    @Override
    public String getCatalogName() {
        return __catalogName;
    }

    @Override
    public String getSchemaName() {
        return __schemaName;
    }

    @Override
    public String getTableName() {
        return getTableName(org.seasar.doma.jdbc.Naming.DEFAULT::apply);
    }

    @Override
    public String getTableName(java.util.function.BiFunction<org.seasar.doma.jdbc.entity.NamingType, String, String> namingFunction) {
        if (__tableName.isEmpty()) {
            return namingFunction.apply(__namingType, __name);
        }
        return __tableName;
    }

    @Override
    public boolean isQuoteRequired() {
        return __isQuoteRequired;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void preInsert(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PreInsertContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.preInsert(entity, context);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void preUpdate(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PreUpdateContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.preUpdate(entity, context);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void preDelete(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PreDeleteContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.preDelete(entity, context);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void postInsert(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PostInsertContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.postInsert(entity, context);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void postUpdate(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PostUpdateContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.postUpdate(entity, context);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public void postDelete(ck.common.entity.MyTable entity, org.seasar.doma.jdbc.entity.PostDeleteContext<ck.common.entity.MyTable> context) {
        Class __listenerClass = jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener.class;
        jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener __listener = context.getConfig().getEntityListenerProvider().get(__listenerClass, __listenerSupplier);
        __listener.postDelete(entity, context);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> getEntityPropertyTypes() {
        return __entityPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?> getEntityPropertyType(String __name) {
        return __entityPropertyTypeMap.get(__name);
    }

    @Override
    public java.util.List<org.seasar.doma.jdbc.entity.EntityPropertyType<ck.common.entity.MyTable, ?>> getIdPropertyTypes() {
        return __idPropertyTypes;
    }

    @Override
    public org.seasar.doma.jdbc.entity.GeneratedIdPropertyType<java.lang.Object, ck.common.entity.MyTable, ?, ?> getGeneratedIdPropertyType() {
        return $id;
    }

    @Override
    public org.seasar.doma.jdbc.entity.VersionPropertyType<jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity, ck.common.entity.MyTable, ?, ?> getVersionPropertyType() {
        return $versionNo;
    }

    @Override
    public ck.common.entity.MyTable newEntity(java.util.Map<String, org.seasar.doma.jdbc.entity.Property<ck.common.entity.MyTable, ?>> __args) {
        ck.common.entity.MyTable entity = new ck.common.entity.MyTable();
        __args.values().forEach(v -> v.save(entity));
        return entity;
    }

    @Override
    public Class<ck.common.entity.MyTable> getEntityClass() {
        return ck.common.entity.MyTable.class;
    }

    @Override
    public ck.common.entity.MyTable getOriginalStates(ck.common.entity.MyTable __entity) {
        return null;
    }

    @Override
    public void saveCurrentStates(ck.common.entity.MyTable __entity) {
    }

    /**
     * @return the singleton
     */
    public static _MyTable getSingletonInternal() {
        return __singleton;
    }

    /**
     * @return the new instance
     */
    public static _MyTable newInstance() {
        return new _MyTable();
    }

    private static class ListenerHolder {
        private static jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener<ck.common.entity.MyTable> listener = new jp.co.idnet.ideale.persistence.doma.listener.CommonFieldEntityListener<>();
    }

}
