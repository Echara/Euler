package h2;

import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.h2.tools.RunScript;
import org.h2.util.JdbcUtils;
import org.springframework.core.io.ClassPathResource;
/**
 * 「jdbc:h2:tcp://localhost:9092/~/h2/sample;」のURLでh2を起動。
 *   ツールを利用してh2にアクセスする場合は、上記のURLを利用してください。<br>
 *   ブラウザからh2にアクセスする場合は、「http://localhost:8082」にアクセスしてください。
 */
public class H2DefaultDBManager {
    public static String WEB_PORT = "8082";
    public static String TCP_PORT = "9092";
    private static String DEFAULT_DB_TCP_URI = "tcp://localhost:" + TCP_PORT;
    public static String DEFAULT_DB_TCP_PATH = "jdbc:h2:" + DEFAULT_DB_TCP_URI;
    public static String DEFAULT_DB_DATAFILE = "~/h2/sample;DB_CLOSE_DELAY=-1";
    public static String SLASH = "/";
    public static String DEFAULT_DB_TCP_URL = DEFAULT_DB_TCP_PATH + SLASH + DEFAULT_DB_DATAFILE;
    public static String USERNAME = "sa";
    public static String PASSWORD = "";
    public static String UTF8 = "UTF-8";
    public static String SCHEMA_SQL_FILE_PATH = "db/schema-h2.sql";
    public static String DATA_SQL_FILE_PATH = "db/data.sql";
    public static void start() {
        try {
            org.h2.tools.Server.main(
                    "-tcp", "-tcpAllowOthers", "-tcpPort", TCP_PORT,
                    "-web", "-webAllowOthers" ,"-webPort", WEB_PORT);
            if (H2DefaultDBManager.isNotInitialized()) {
                H2DefaultDBManager.initializeSampleData();
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public static void stop() {
        try {
            org.h2.tools.Server.main("-tcpShutdown", DEFAULT_DB_TCP_URI);
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean isRunning() {
        Connection conn = null;
        boolean isRunning = true;
        try {
            org.h2.Driver.load();
            conn = DriverManager.getConnection(DEFAULT_DB_TCP_URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            isRunning = false;
        } finally {
            JdbcUtils.closeSilently(conn);
        }
        return isRunning;
    }

    public static boolean isNotInitialized() {
         Connection conn = null;
         Statement stat = null;
         ResultSet resultSet = null;
         boolean notTableExists = true;

         try {
             org.h2.Driver.load();
             conn = DriverManager.getConnection(DEFAULT_DB_TCP_URL, USERNAME, PASSWORD);
             resultSet = conn.getMetaData().getTables(null, null, "M_USER", null);
             if (resultSet.next()) {
                 notTableExists = false;
             }
         } catch (SQLException e) {
             e.printStackTrace();
         } finally {
             JdbcUtils.closeSilently(resultSet);
             JdbcUtils.closeSilently(stat);
             JdbcUtils.closeSilently(conn);
         }
         return notTableExists;
    }

    public static void initializeSampleData() {
          ClassPathResource schemaH2Sql = new ClassPathResource(SCHEMA_SQL_FILE_PATH);
          ClassPathResource dataSql = new ClassPathResource(DATA_SQL_FILE_PATH);
          try {
            RunScript.execute(DEFAULT_DB_TCP_URL, USERNAME, PASSWORD,schemaH2Sql.getFile().getAbsolutePath(), Charset.forName(UTF8), false);
            RunScript.execute(DEFAULT_DB_TCP_URL, USERNAME, PASSWORD,dataSql.getFile().getAbsolutePath(), Charset.forName(UTF8), false);
          } catch (Exception e) {
             e.printStackTrace();
        }
    }
}
