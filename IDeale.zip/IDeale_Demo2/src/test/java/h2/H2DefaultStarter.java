package h2;

public class H2DefaultStarter {
    public static void main(String[] args) {
        if (!H2DefaultDBManager.isRunning()) {
            H2DefaultDBManager.start();
        }
    }
}
