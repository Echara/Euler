var LoginUtil = (function() {

  function LoginUtil() {
  }

  LoginUtil.beforeLogin = function() {
    StorageUtil.save("saveUserId", document
        .getElementById("login:saveUserId_input").checked);
    if (document.getElementById("login:saveUserId_input").checked) {
      StorageUtil.save("userId",
          document.getElementById("login:userId").value);
    } else {
      StorageUtil.remove("userId");
    }
  };

  return LoginUtil;
})();

$(function() {
  if (StorageUtil.validWebStorage) {
    if (StorageUtil.get("saveUserId")
        && (StorageUtil.get("saveUserId") === "true")) {
      PrimefacesUtil.onSelectBooleanCheckbox("#login\\:saveUserId");
    } else {
      PrimefacesUtil.offSelectBooleanCheckbox("#login\\:saveUserId");
    }
    document.getElementById("login:userId").value = StorageUtil.get("userId");
  }
});