/**
 * Web Storage関連のUtil。
 */
var StorageUtil = (function() {

  function StorageUtil() {
    // empty implemented.
  }

  StorageUtil.save = function(key, value) {
    if (StorageUtil.validWebStorage()) {
      localStorage.setItem(key, value);
    }
  };

  StorageUtil.remove = function(key) {
    if (StorageUtil.validWebStorage()) {
      localStorage.removeItem(key);
    }
  };

  StorageUtil.get = function(key) {
    if (StorageUtil.validWebStorage()) {
      return localStorage.getItem(key);
    }
  };

  StorageUtil.validWebStorage = function() {
    if (typeof (Storage) !== "undefined") {
      return true;
    } else {
      console.error("ご利用のブラウザではWeb Storageが利用できません。");
      return false;
    }
  };

  return StorageUtil;
})();

/**
 * Primefaces関連のUtil。
 */
var PrimefacesUtil = (function() {

  function PrimefacesUtil() {
    // empty implemented.
  }

  // selectorにはjQueryセレクタフォーマットでSelectBooleanCheckboxコンポーネントのIDを指定すること
  PrimefacesUtil.onSelectBooleanCheckbox = function(id) {
    var checkbox = $(id + "_input");
    checkbox.prop("checked", true);
    checkbox.attr("aria-checked", true);
    $(id).find('div.ui-chkbox-box').addClass('ui-state-active');
    var span = $(id).find('span.ui-chkbox-icon');
    span.removeClass('ui-icon-blank');
    span.addClass('ui-icon-check');
  };

  // selectorにはjQueryセレクタフォーマットでSelectBooleanCheckboxコンポーネントのIDを指定すること
  PrimefacesUtil.offSelectBooleanCheckbox = function(id) {
    var checkbox = $(id + "_input");
    checkbox.prop("checked", false);
    checkbox.attr("aria-checked", false);
    $(id).find('div.ui-chkbox-box').removeClass('ui-state-active');
    var span = $(id).find('span.ui-chkbox-icon');
    span.addClass('ui-icon-blank');
    span.removeClass('ui-icon-check');
  };

  return PrimefacesUtil;
})();

/**
 * カレンダー関連のUtil。
 */
var CalendarUtil = (function() {
  function CalendarUtils() {
    // empty implemented.
  }
  CalendarUtils.isSunday = function(date) {
    return date.getDay() === 0 ? true : false;
  };
  CalendarUtils.isSaturday = function(date) {
    return date.getDay() === 6 ? true : false;
  };
  return CalendarUtils;
})();

/**
 * カレンダーマネージャ。
 */
var CalendarManager = (function () {
  function CalendarManager() {
      this.holidays = null;
      if (CalendarManager.instance) {
          throw new Error("newではなくgetInstanceを利用してください。");
      }
      CalendarManager.instance = this;
  }
  CalendarManager.getInstance = function () {
      if (CalendarManager.instance === null) {
          CalendarManager.instance = new CalendarManager();
      }
      return CalendarManager.instance;
  };
  CalendarManager.prototype.init = function () {
      if (typeof initBusinessHolidays == "function") {
          initBusinessHolidays();
      }
      else {
          console.info("initBusinessHolidays関数が定義されていないため、実行しませんでした。");
      }
  };
  /**
   * p:remoteCommand name="initBusinessHolidays"定義のoncomplete属性として利用するコールバックメソッド。
   * Primefaces経由でサーバ側のActionメソッドを非同期呼び出しし、戻り値として休日配列を持つJSONを取得、holidaysに格納する。
   */
  CalendarManager.prototype.initBusinessHolidaysCallBack = function (xhr, status, args) {
      CalendarManager.getInstance().holidays = JSON.parse(args.holidays);
  };
  /**
   * p:calendar beforeShowDay属性として利用するメソッド。
   */
  CalendarManager.prototype.beforeShowDay = function (date) {
      var cssClass = CalendarManager.getInstance().getHolidayCssClass(date);
      return [true, cssClass, ''];
  };
  CalendarManager.prototype.hasHolidays = function () {
      if (CalendarManager.getInstance().holidays === null) {
          return false;
      }
      return true;
  };
  CalendarManager.prototype.isHoliday = function (date) {
      var calendarManager = CalendarManager.getInstance();
      if (calendarManager.holidays === null) {
          return false;
      }
      for (var i = 0; i < calendarManager.holidays.length; i++) {
          if (new Date(calendarManager.holidays[i]).getTime() === date.getTime()) {
              return true;
          }
      }
      return false;
  };
  CalendarManager.prototype.getHolidayCssClass = function (date) {
      if (CalendarManager.getInstance().isHoliday(date)) {
          return 'holiday';
      }
      else if (CalendarUtil.isSunday(date)) {
          return 'sunday';
      }
      else if (CalendarUtil.isSaturday(date)) {
          return 'saturday';
      }
      return '';
  };
  CalendarManager.instance = null;
  return CalendarManager;
})();


// 画面ロード後の処理
$(function() {
  // 初期化処理
  var calendarManager = CalendarManager.getInstance();
  calendarManager.init();
});