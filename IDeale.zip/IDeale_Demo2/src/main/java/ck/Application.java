package ck;

import org.springframework.boot.SpringApplication;

import jp.co.idnet.ideale.autoconfigure.IdealeSpringBootApplication;

/**
 * アプリケーション実行クラス。
 */
@IdealeSpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
