package ck;


import org.apache.catalina.Context;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatContextCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * アプリケーションの基本的な設定をSpring Bean定義するクラス。
 * @author 渡辺 暁
 *
 */
@Configuration
public class ApplicationConfig {

  /**
   * 組み込みサーブレットコンテナ(APサーバ)に関する設定を定義したクラスを返す。
   * @return EmbeddedServletContainerFactory
   */
  @Bean
  public EmbeddedServletContainerFactory servletContainer() {
    TomcatEmbeddedServletContainerFactory factory = new TomcatEmbeddedServletContainerFactory();
    TomcatContextCustomizer contextCustomizer = new TomcatContextCustomizer() {
      @Override
      public void customize(Context context) {
        context.addWelcomeFile("index.html");
      }
    };
    factory.addContextCustomizers(contextCustomizer);
    return factory;
  }
}
