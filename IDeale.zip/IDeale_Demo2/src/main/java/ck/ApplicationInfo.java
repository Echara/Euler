package ck;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * アプリ固有の静的な設定を保持するクラス。<br>
 * Application.yml類に定義した"app"の接頭辞を持つ定義がアプリ稼働時に設定される。
 * @author Y.Fujimoto
 *
 */
@Component
@ConfigurationProperties(prefix = "app")
public class ApplicationInfo {

  /**
   * アプリケーションのバージョンを示す文字列。<br>
   * app.version
   */
  private String version;
  /**
   * 一時ファイルを格納するディレクトリ。<br>
   * app.temporary-dir
   */
  private String temporaryDir;

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getTemporaryDir() {
    return temporaryDir;
  }

  public void setTemporaryDir(String temporaryDir) {
    this.temporaryDir = temporaryDir;
  }
}
