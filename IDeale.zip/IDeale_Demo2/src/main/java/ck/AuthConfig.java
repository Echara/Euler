package ck;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import ck.common.auth.SampleJdbcRealm;
import jp.co.idnet.ideale.shiro.customizer.JdbcRealmCustomizer;
import jp.co.idnet.ideale.shiro.customizer.ShiroFilterFactoryBeanCustomizer;

/**
 * アプリケーションのユーザ認証に関するSpring Bean定義を行うクラス。
 *
 */
@Configuration
public class AuthConfig {

  /**
   * ShiroのFilterに関する設定を定義したクラスを返す。
   * @return ShiroFilterFactoryBeanCustomizer
   * @throws Exception 例外
   */
  @Bean
  public ShiroFilterFactoryBeanCustomizer shiroFilterFactoryBeanCustomizer() throws Exception {
    ShiroFilterFactoryBeanCustomizer customizer = new ShiroFilterFactoryBeanCustomizer();

    customizer.setSuccessUrl("/pages/system/account/b/b01/b01Home.xhtml");
    customizer.setLoginUrl("/pages/system/general/auth/login.xhtml");
    customizer.setUnauthorizedUrl("/pages/system/general/error/static/access-denied.xhtml");

    customizer.putFilterChainDefinition("/pages/system/general/error/**", "anon");
    customizer.putFilterChainDefinition("/pages/system/general/auth/login.xhtml", "authc");// authc
    customizer.putFilterChainDefinition("/javax.faces.resource/dynamiccontent.properties.xhtml", "authc");// authc
    customizer.putFilterChainDefinition("/pages/**", "authc");// authc
    customizer.putFilterChainDefinition("/logout", "logout");
    customizer.putFilterChainDefinition("/resources/**", "anon");
    customizer.putFilterChainDefinition("/index.html", "anon");

    customizer.putFilter("authc", customizer.getIdealeFormAuthenticationFilter());
    return customizer;
  }

  /**
   * ShiroのRealmに関する設定を定義したクラスを返す。
   * @return JdbcRealmCustomizer
   */
  @Bean
  public JdbcRealmCustomizer jdbcRealmCustomizer() {
    JdbcRealmCustomizer jdbcRealmCustomizer = new JdbcRealmCustomizer();

    jdbcRealmCustomizer.setJdbcRealm(new SampleJdbcRealm());
    jdbcRealmCustomizer.setPermissionsLookupEnabled(false);

    return jdbcRealmCustomizer;
  }
}
