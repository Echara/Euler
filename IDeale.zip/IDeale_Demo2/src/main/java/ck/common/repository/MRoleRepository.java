package ck.common.repository;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Stream;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.SelectType;

import jp.co.idnet.ideale.persistence.doma.dao.annotation.DomaRepository;
import ck.common.repository.generated.MRoleRepositoryGGP;
import ck.common.entity.MRole;

/**
 * MRoleのデータアクセスクラスです。
 */
@Dao
@DomaRepository
public interface MRoleRepository extends MRoleRepositoryGGP {

  /**
   * 全件取得する。
   *
   * @return MRoleエンティティ
   */
  @Select
  public List<MRole> selectAll();

  /**
   * ユーザIDを基にユーザが持つロールを取得する。
   *
   * @return MRoleエンティティ
   */
  @Select
  public List<MRole> selectByUserId(String userId);

  @Select(strategy = SelectType.STREAM)
  public Map<String, MRole> selectAllToMap(Function<Stream<MRole>, Map<String, MRole>> mapper);

}
