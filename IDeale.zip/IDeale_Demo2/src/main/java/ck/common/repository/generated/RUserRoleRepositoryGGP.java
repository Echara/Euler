package ck.common.repository.generated;

import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

import ck.common.entity.RUserRole;

/**
 * RUserRoleのデータアクセスクラスです。
 */
@Dao
public interface RUserRoleRepositoryGGP {

    /**
     * 主キーでの検索を行います。
     * @param pk
     * @return the RUserRole entity
     */
    @Select
    RUserRole selectById(Long pk);

    /**
     * 主キー+バージョンでの検索を行います。
     * @param pk
     * @param versionNo
     * @return the RUserRole entity
     */
    @Select(ensureResult = true)
    RUserRole selectByIdAndVersion(Long pk, Long versionNo);

    /**
     * 引数に渡されたRUserRoleを登録します。
     * @param entity RUserRole
     * @return affected rows
     */
    @Insert
    int insert(RUserRole entity);

    /**
     * 引数に渡されたRUserRoleを更新します。
     * @param entity RUserRole
     * @return affected rows
     */
    @Update
    int update(RUserRole entity);

   /**
    * 引数に渡されたRUserRoleを物理削除する。
    * @param entity
    * @return affected rows
    */
    @Delete
    int delete(RUserRole entity);

}