package ck.common.repository;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;

import ck.common.entity.MUser;
import ck.common.repository.generated.MUserRepositoryGGP;
import jp.co.idnet.ideale.persistence.doma.dao.annotation.DomaRepository;

/**
 * TUserのデータアクセスクラスです。
 */
@Dao
@DomaRepository
public interface MUserRepository extends  MUserRepositoryGGP {

  /**
   * ユーザIDを基にユーザエンティティを取得する。
   *
   * @param userId ユーザID
   * @return ユーザエンティティ
   */
  @Select
  public MUser selectByUserId(String userId);

  @Select
  List<MUser> selectAll();
}