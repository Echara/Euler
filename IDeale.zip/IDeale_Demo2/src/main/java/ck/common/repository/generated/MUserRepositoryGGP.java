package ck.common.repository.generated;

import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

import ck.common.entity.MUser;

/**
 * MUserのデータアクセスクラスです。
 */
@Dao
public interface MUserRepositoryGGP {

    /**
     * 主キーでの検索を行います。
     * @param pk
     * @return the MUser entity
     */
    @Select
    MUser selectById(Long pk);

    /**
     * 主キー+バージョンでの検索を行います。
     * @param pk
     * @param versionNo
     * @return the MUser entity
     */
    @Select(ensureResult = true)
    MUser selectByIdAndVersion(Long pk, Long versionNo);

    /**
     * 引数に渡されたMUserを登録します。
     * @param entity MUser
     * @return affected rows
     */
    @Insert
    int insert(MUser entity);

    /**
     * 引数に渡されたMUserを更新します。
     * @param entity MUser
     * @return affected rows
     */
    @Update
    int update(MUser entity);

   /**
    * 引数に渡されたMUserを物理削除する。
    * @param entity
    * @return affected rows
    */
    @Delete
    int delete(MUser entity);

}