package ck.common.repository;

import org.seasar.doma.Dao;

import jp.co.idnet.ideale.persistence.doma.dao.annotation.DomaRepository;
import ck.common.repository.generated.RUserRoleRepositoryGGP;

/**
 * RUserRoleのデータアクセスクラスです。
 */
@Dao
@DomaRepository
public interface RUserRoleRepository extends  RUserRoleRepositoryGGP {

}