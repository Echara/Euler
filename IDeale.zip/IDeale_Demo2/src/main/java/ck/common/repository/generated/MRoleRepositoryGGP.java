package ck.common.repository.generated;

import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;

import ck.common.entity.MRole;


/**
 * MRoleのデータアクセスクラスです。
 */
@Dao
public interface MRoleRepositoryGGP {

    /**
     * 主キーでの検索を行います。
     * @param pk
     * @return the MRole entity
     */
    @Select
    MRole selectById(Long pk);

    /**
     * 主キー+バージョンでの検索を行います。
     * @param pk
     * @param versionNo
     * @return the MRole entity
     */
    @Select(ensureResult = true)
    MRole selectByIdAndVersion(Long pk, Long versionNo);

    /**
     * 引数に渡されたMRoleを登録します。
     * @param entity MRole
     * @return affected rows
     */
    @Insert
    int insert(MRole entity);

    /**
     * 引数に渡されたMRoleを更新します。
     * @param entity MRole
     * @return affected rows
     */
    @Update
    int update(MRole entity);

   /**
    * 引数に渡されたMRoleを物理削除する。
    * @param entity
    * @return affected rows
    */
    @Delete
    int delete(MRole entity);

}