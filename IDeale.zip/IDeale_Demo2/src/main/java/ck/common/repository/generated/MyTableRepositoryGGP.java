package ck.common.repository.generated;

import org.seasar.doma.Dao;

@Dao
public interface MyTableRepositoryGGP {


}
