package ck.common.entity;
import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.GeneratedValue;
import org.seasar.doma.GenerationType;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity;

/**
 *
 */
@Entity
@Table(name = "m_user")
public class MUser extends CommonFieldEntity {

    /**  */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pk")
    private Long pk;

    /**  */
    @Column(name = "user_id")
    private String userId;

    /**  */
    @Column(name = "user_name")
    private String userName;

    /**  */
    @Column(name = "password")
    private String password;

    /**
     * Returns the pk.
     *
     * @return the pk
     */
    public Long getPk() {
        return pk;
    }

    /**
     * Sets the pk.
     *
     * @param pk the pk
     */
    public void setPk(Long pk) {
        this.pk = pk;
    }

    /**
     * Returns the userId.
     *
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the userId.
     *
     * @param userId the userId
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Returns the userName.
     *
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the userName.
     *
     * @param userName the userName
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Returns the password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     *
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }
}