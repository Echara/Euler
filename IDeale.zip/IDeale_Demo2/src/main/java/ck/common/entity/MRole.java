package ck.common.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.GeneratedValue;
import org.seasar.doma.GenerationType;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity;

/**
 *
 */
@Entity
@Table(name = "m_role")
public class MRole extends CommonFieldEntity {

    /**  */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pk")
    private Long pk;

    /**  */
    @Column(name = "key_value")
    private String keyValue;

    /**  */
    @Column(name = "display_name")
    private String displayName;

    /**
     * Returns the pk.
     *
     * @return the pk
     */
    public Long getPk() {
        return pk;
    }

    /**
     * Sets the pk.
     *
     * @param pk the pk
     */
    public void setPk(Long pk) {
        this.pk = pk;
    }

    /**
     * Returns the keyValue.
     *
     * @return the keyValue
     */
    public String getKeyValue() {
        return keyValue;
    }

    /**
     * Sets the keyValue.
     *
     * @param keyValue the keyValue
     */
    public void setKeyValue(String keyValue) {
        this.keyValue = keyValue;
    }

    /**
     * Returns the displayName.
     *
     * @return the displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the displayName.
     *
     * @param displayName the displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}