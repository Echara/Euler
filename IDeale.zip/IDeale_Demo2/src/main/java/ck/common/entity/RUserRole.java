package ck.common.entity;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.GeneratedValue;
import org.seasar.doma.GenerationType;
import org.seasar.doma.Id;
import org.seasar.doma.Table;

import jp.co.idnet.ideale.persistence.doma.entity.CommonFieldEntity;

/**
 *
 */
@Entity
@Table(name = "r_user_role")
public class RUserRole extends CommonFieldEntity {

    /**  */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pk")
    private Long pk;

    /**  */
    @Column(name = "user_pk")
    private Long userPk;

    /**  */
    @Column(name = "role_pk")
    private Long rolePk;

    /**
     * Returns the pk.
     *
     * @return the pk
     */
    public Long getPk() {
        return pk;
    }

    /**
     * Sets the pk.
     *
     * @param pk the pk
     */
    public void setPk(Long pk) {
        this.pk = pk;
    }

    /**
     * Returns the userPk.
     *
     * @return the userPk
     */
    public Long getUserPk() {
        return userPk;
    }

    /**
     * Sets the userPk.
     *
     * @param userPk the userPk
     */
    public void setUserPk(Long userPk) {
        this.userPk = userPk;
    }

    /**
     * Returns the rolePk.
     *
     * @return the rolePk
     */
    public Long getRolePk() {
        return rolePk;
    }

    /**
     * Sets the rolePk.
     *
     * @param rolePk the rolePk
     */
    public void setRolePk(Long rolePk) {
        this.rolePk = rolePk;
    }
}