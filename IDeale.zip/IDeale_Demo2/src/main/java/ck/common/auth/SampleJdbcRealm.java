package ck.common.auth;

import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.jdbc.JdbcRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.idnet.ideale.util.StringUtils;
import jp.co.idnet.ideale.util.internal.IdealeMessageUtils;

/**
 * Sample拡張JdbcRealm。
 */
public class SampleJdbcRealm extends JdbcRealm {

    @Autowired
    private LoginUserFinder service;

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthorizationException {

        UsernamePasswordToken upToken = (UsernamePasswordToken) token;
        String username = upToken.getUsername();

        if (StringUtils.isEmpty(username)) {
            throw new AccountException(IdealeMessageUtils.getMessageOfSpring("Z01_Z001_Z001_E0001"));
        }

        LoginUser loginUser = service.getUserInfo(username);

        if (loginUser == null) {
            throw new UnknownAccountException(IdealeMessageUtils.getMessageOfSpring("Z01_Z001_Z001_E0002", username));
        }

        SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(username,
                loginUser.getUser().getPassword().toCharArray(), getName());

        // Principalに独自の型を設定する
        info.setPrincipals(new SimplePrincipalCollection(loginUser, getName()));

        return info;
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {

        if (principals == null) {
            throw new AuthorizationException(IdealeMessageUtils.getMessageOfSpring("Z01_Z001_Z001_E0003"));
        }

        LoginUser loginUser = (LoginUser) getAvailablePrincipal(principals);

        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        service.loadRoles(loginUser);

        authorizationInfo.setRoles(loginUser.getRoleSet());

        return authorizationInfo;

    }
}
