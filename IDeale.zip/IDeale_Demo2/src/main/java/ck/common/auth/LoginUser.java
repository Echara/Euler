package ck.common.auth;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;

import jp.co.idnet.ideale.core.entity.login.IUserId;
import ck.common.entity.MRole;
import ck.common.entity.MUser;

public class LoginUser implements Serializable, IUserId {
    private MUser user;

    private List<MRole> roles = new ArrayList<>();

    protected LoginUser() {
    };

    public LoginUser(MUser user) {
        this.user = user;
    }

    public MUser getUser() {
        return user;
    }

    public void setUser(MUser user) {
        this.user = user;
    }

    public List<MRole> getRoles() {
        return roles;
    }

    public void setRoles(List<MRole> roles) {
        this.roles = roles;
    }

    public Set<String> getRoleSet() {
        return roles.stream().collect(Collectors.mapping(MRole::getKeyValue, Collectors.toSet()));
    }

    public static LoginUser getLoginUserInfo() {
        Subject subject = SecurityUtils.getSubject();
        return (LoginUser) subject.getPrincipal();
    }

    @Override
    public String getUserId() {
        return user.getUserId();
    }
}
