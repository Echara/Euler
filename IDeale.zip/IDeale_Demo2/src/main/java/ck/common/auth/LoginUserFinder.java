package ck.common.auth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import ck.common.repository.MRoleRepository;
import ck.common.repository.MUserRepository;
import ck.common.entity.MRole;
import ck.common.entity.MUser;
import jp.co.idnet.ideale.web.stereotype.LazyFinder;
import jp.co.idnet.ideale.web.stereotype.tx.LazyFinderTx;

/**
 * Sample Webアプリケーションのユーザ権限関連情報にアクセスするためのアクセサクラス。
 *
 */
@LazyFinder
@LazyFinderTx
public class LoginUserFinder {
    @Autowired
    private MUserRepository userRep;
    @Autowired
    private MRoleRepository roleRep;

    public void loadRoles(LoginUser loginUser) {
        List<MRole> roles = roleRep.selectByUserId(loginUser.getUser().getUserId());
        loginUser.setRoles(roles);
    }

    public LoginUser getUserInfo(String userId) {
        MUser user = userRep.selectByUserId(userId);
        LoginUser loginUser = null;
        if (user != null) {
            loginUser = new LoginUser();
            loginUser.setUser(user);
        }
        return loginUser;
    }

    //////// getter setter ////////
    public MUserRepository getUserRep() {
        return userRep;
    }

    public void setUserRep(MUserRepository userRep) {
        this.userRep = userRep;
    }

    public MRoleRepository getRoleRep() {
        return roleRep;
    }

    public void setRoleRep(MRoleRepository roleRep) {
        this.roleRep = roleRep;
    }
}
