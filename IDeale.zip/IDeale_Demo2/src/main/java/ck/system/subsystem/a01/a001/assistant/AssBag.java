package ck.system.subsystem.a01.a001.assistant;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;

import ck.common.entity.MRole;
import jp.co.idnet.ideale.core.message.Messages;
import jp.co.idnet.ideale.web.stereotype.Bag;

@Bag
public class AssBag implements Serializable {
    private String userId;

    private MRole selectedKeyValue;

    private Map<String, MRole> roleMaps = null;

    private List<MRole> mRoleList = new ArrayList<>();

    private LazyDataModel<Person> model;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

//    public String getSelectedKeyValue() {
//        return selectedKeyValue;
//    }
//
//    public void setSelectedKeyValue(String selectedKeyValue) {
//        this.selectedKeyValue = selectedKeyValue;
//    }

    public LazyDataModel<Person> getModel() {
        return model;
    }

    public void setModel(LazyDataModel<Person> model) {
        this.model = model;
    }

    public Map<String, MRole> getRoleMaps() {
        return roleMaps;
    }

    public MRole getSelectedKeyValue() {
        return selectedKeyValue;
    }

    public void setSelectedKeyValue(MRole selectedKeyValue) {
        this.selectedKeyValue = selectedKeyValue;
    }

    public void setRoleMaps(Map<String, MRole> roleMaps) {
        this.roleMaps = roleMaps;
    }

    public void validate(Messages messages) {
        System.out.println("validate");
       // messages.addErrorMessage("login:userId", "aaa");
    }

    public List<MRole> getmRoleList() {
        return mRoleList;
    }

    public void setmRoleList(List<MRole> mRoleList) {
        this.mRoleList = mRoleList;
    }

}
