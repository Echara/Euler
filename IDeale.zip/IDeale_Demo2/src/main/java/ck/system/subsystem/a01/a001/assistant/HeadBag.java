package ck.system.subsystem.a01.a001.assistant;

import java.io.Serializable;

import org.primefaces.model.LazyDataModel;

import ck.common.entity.MUser;
import jp.co.idnet.ideale.web.stereotype.Bag;

@Bag
public class HeadBag implements Serializable {
	private LazyDataModel<MUser> ldm;

	public LazyDataModel<MUser> getLdm() {
		return ldm;
	}

	public void setLdm(LazyDataModel<MUser> ldm) {
		this.ldm = ldm;
	}

}
