package ck.system.subsystem.a01.a001;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;

import ck.common.entity.MRole;
import ck.common.repository.MRoleRepository;
import ck.system.subsystem.a01.a001.assistant.AssBag;
import ck.system.subsystem.a01.a001.assistant.Person;
import jp.co.idnet.ideale.web.jsf.Pages;
import jp.co.idnet.ideale.web.stereotype.Page;
import jp.co.idnet.ideale.web.stereotype.tx.PageMethodTx;

@Page
public class A01A001HomePage {
    @Autowired
    private AssBag assBag;
    @Autowired
    private A01A001HomeService a01A001HomeService;

    @Autowired
    MRoleRepository mRoleRepository ;

    //@PageMethodTx
    public void init() {
//        assBag.setRoleMaps(mRoleRepository.selectAllToMap(stream -> {
//            return stream.collect(Collectors.toMap(MRole::getKeyValue , r -> r));
//        }));
        MRole mRole = new MRole();
        mRole.setKeyValue("Key1");
        mRole.setDisplayName("DisplayName1");
        assBag.getmRoleList().add(mRole);
        mRole = new MRole();
        mRole.setKeyValue("Key2");
        mRole.setDisplayName("DisplayName2");
        assBag.getmRoleList().add(mRole);

        assBag.setModel(new LazyDataModel<Person>() {
            @Override
            public List<Person> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                    Map<String, Object> filters) {
                    System.out.println(String.format("LazyDataModel#load(first=%d,pageSize=%d,sortField=%s,sortOrder=%s,filters=%s",
                            first, pageSize, sortField, sortOrder, filters));
                    List<Person> l = new ArrayList<>();
                    for ( int i = 0 ; i < pageSize; i++) {
                        Person p = new Person();
                        p.setId(first + i);
                        p.setName( "田中 太郎" + p.getId());
                        l.add(p);
                    }
                    return l;
           }
        });
        assBag.getModel().setRowCount(10000);
    }
    //@PageMethodTx
    public String doSubmit() {
        System.out.println("*** doSubmit ***");
        return null;
    }

    public AssBag getAssBag() {
        return assBag;
    }

    public void setAssBag(AssBag assBag) {
        this.assBag = assBag;
    }

    public String doDelete() {
    	System.out.println(assBag.getModel().getRowData().getId());
        return null;
    }

    @PageMethodTx
    public String doShow() {
        System.out.println("*** doShow ***");
        return Pages.toPage(A01A001_m_userPage.class).build();
    }

}
