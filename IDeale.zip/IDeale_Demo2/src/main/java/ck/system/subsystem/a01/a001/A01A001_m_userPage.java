package ck.system.subsystem.a01.a001;

import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;

import ck.common.entity.MUser;
import ck.common.repository.MUserRepository;
import ck.system.subsystem.a01.a001.assistant.HeadBag;
import jp.co.idnet.ideale.core.message.Messages;
import jp.co.idnet.ideale.web.jsf.Pages;
import jp.co.idnet.ideale.web.stereotype.Page;
import jp.co.idnet.ideale.web.stereotype.tx.PageMethodTx;

@Page
public class A01A001_m_userPage {
//    @Autowired
//    private BagScopeReceptionist bagScopeReceptionist;
    @Autowired
    private Messages messages;
    @Autowired
    private HeadBag headBag;
    @Autowired
    MUserRepository mUserRepository;

    @PageMethodTx
    public void init() {
        System.out.println("*** A01A001_m_userPage init ***");
        List<MUser> l = mUserRepository.selectAll();
        System.out.println("1-------------"+l.size());

        headBag.setLdm(new LazyDataModel<MUser>() {
            @Override
            public List<MUser> load(int first, int pageSize, String sortField, SortOrder sortOrder,
                    Map<String, Object> filters) {
            		//List<MUser> l = mUserRepository.selectAll();
                    return l;
           }
        });
        headBag.getLdm().setRowCount(l.size());
        System.out.println("2---------------"+headBag.getLdm().getRowCount());
    }

    @PageMethodTx
    public String doSubmit() {
        System.out.println("*** doSubmit ***");
        return Pages.toPage(A01A001HomePage.class).build();
        //return Pages.toPage(HelloworldPage.class).build();
    }

	public HeadBag getHeadBag() {
		return headBag;
	}

	public void setHeadBag(HeadBag headBag) {
		this.headBag = headBag;
	}


}