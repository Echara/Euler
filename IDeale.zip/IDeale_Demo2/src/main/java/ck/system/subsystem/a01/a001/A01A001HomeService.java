package ck.system.subsystem.a01.a001;

import jp.co.idnet.ideale.web.stereotype.BizService;

@BizService
public class A01A001HomeService {
    public String getName() {
        return "A01A001HomeService#getName";
    }
}
