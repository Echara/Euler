package ck.system.general.auth;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.idnet.ideale.core.message.Messages;
import jp.co.idnet.ideale.web.jsf.Pages;
import jp.co.idnet.ideale.web.stereotype.Page;
import jp.co.idnet.ideale.web.stereotype.tx.PageMethodTx;
import ck.common.auth.LoginUser;
import ck.system.general.auth.assistant.LoginPageBag;
import ck.system.subsystem.a01.a001.A01A001HomePage;

/**
 * ログイン画面のページクラス。
 */
@Page
public class LoginPage {
    @Autowired
    private LoginPageBag bag;
    @Autowired
    private Messages messages;
    @Autowired
    private LoginService loginService;

    /**
     * ログイン処理を行う。
     * ログイン認証が成功した場合は、ログインユーザクラスにロール情報をセットし、Home画面に遷移する。<br>
     * ログイン認証が失敗した場合は、エラーメッセージをセットしてログイン画面へ遷移する。<br>
     * @return 成功:A01A001HomePageのURL 失敗:LoginPageのURL
     */
    @PageMethodTx public String login() {
        if (SecurityUtils.getSubject().isAuthenticated()) {
            LoginUser loginUser = LoginUser.getLoginUserInfo();
            loginService.loadRoles(loginUser);
            return Pages.toPage(A01A001HomePage.class).build();
        }
        messages.addErrorGlobalMessage("X01_X001_A001_E0001");
        return Pages.toSelfPage().build();
    }

    public LoginPageBag getBag() {
        return bag;
    }

    public void setBag(LoginPageBag bag) {
        this.bag = bag;
    }

    public Messages getMessages() {
        return messages;
    }

    public void setMessages(Messages messages) {
        this.messages = messages;
    }
}
