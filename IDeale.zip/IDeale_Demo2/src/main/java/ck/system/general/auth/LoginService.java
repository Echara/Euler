package ck.system.general.auth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import ck.common.auth.LoginUser;
import ck.common.entity.MRole;
import ck.common.repository.MRoleRepository;
import jp.co.idnet.ideale.web.stereotype.BizService;
import jp.co.idnet.ideale.web.stereotype.tx.ServiceTx;

@BizService
@ServiceTx
public class LoginService {
    @Autowired
    private MRoleRepository roleRepository;

    public void loadRoles(LoginUser loginUser) {
        List<MRole> roles = roleRepository.selectByUserId(loginUser.getUser().getUserId());
        loginUser.setRoles(roles);
    }

}
