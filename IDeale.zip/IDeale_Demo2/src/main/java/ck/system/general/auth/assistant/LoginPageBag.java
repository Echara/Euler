package ck.system.general.auth.assistant;

import java.io.Serializable;

import jp.co.idnet.ideale.web.stereotype.Bag;

/**
 * ログイン機能のBagクラス。
 *
 * @author 渡辺 暁
 */
@Bag
public class LoginPageBag implements Serializable {
  /** ユーザID。 */
  private String userId;
  /** パスワード。 */
  private String password;

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}
