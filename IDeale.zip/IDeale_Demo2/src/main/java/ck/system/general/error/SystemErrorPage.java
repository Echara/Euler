package ck.system.general.error;

import org.primefaces.application.exceptionhandler.ExceptionInfo;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.idnet.ideale.web.stereotype.Page;


@Page
public class SystemErrorPage {
    @Autowired
    private ExceptionInfo exceptionInfo;

    public ExceptionInfo getExceptionInfo() {
        return exceptionInfo;
    }

    public void setExceptionInfo(ExceptionInfo exceptionInfo) {
        this.exceptionInfo = exceptionInfo;
    }
}
