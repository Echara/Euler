select
  m_role.pk,
  m_role.key_value,
  m_role.display_name,
  m_role.version_no,
  m_role.created_user_id,
  m_role.created_date_time,
  m_role.updated_user_id,
  m_role.updated_date_time
from
  (m_role inner join r_user_role on r_user_role.role_pk = m_role.pk)
  inner join m_user on m_user.pk = r_user_role.user_pk
  where
  m_user.user_id = /* userId */'admin'
