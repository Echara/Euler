select
  /*%expand*/*
from
  r_user_role
where
  pk = /* pk */1
