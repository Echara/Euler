select
  /*%expand*/*
from
  r_user_role
where
  pk = /* pk */1
  and
  version_no = /* versionNo */1
