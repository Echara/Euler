select
  /*%expand*/*
from
  m_role
