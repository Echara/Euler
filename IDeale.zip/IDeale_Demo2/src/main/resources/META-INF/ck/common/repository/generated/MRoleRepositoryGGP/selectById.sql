select
  /*%expand*/*
from
  m_role
where
  pk = /* pk */1
