select
  /*%expand*/*
from
  m_role
where
  pk = /* pk */1
  and
  version_no = /* versionNo */1
