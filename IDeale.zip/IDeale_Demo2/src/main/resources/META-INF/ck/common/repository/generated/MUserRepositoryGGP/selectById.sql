select
  /*%expand*/*
from
  m_user
where
  pk = /* pk */1
