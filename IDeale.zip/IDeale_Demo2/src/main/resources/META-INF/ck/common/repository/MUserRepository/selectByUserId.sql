select
  /*%expand*/*
from
  m_user
where
  user_id = /* userId */'admin'
