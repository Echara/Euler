select
  /*%expand*/*
from
  m_user
