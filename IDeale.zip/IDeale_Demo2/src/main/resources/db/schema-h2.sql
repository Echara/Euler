
/* Drop Tables */

--DROP TABLE r_user_role;
--DROP TABLE m_role;
--DROP TABLE m_user;




/* Create Tables */

-- ロールマスタ
CREATE TABLE m_role
(
  -- PK
  pk bigint NOT NULL,
  -- キー
  key_value varchar(50) NOT NULL UNIQUE,
  -- 表示名
  display_name varchar(100) NOT NULL,
  -- バージョン
  version_no bigint NOT NULL,
  -- 作成ユーザーID
  created_user_id varchar(30) NOT NULL,
  -- 作成日時
  created_date_time datetime NOT NULL,
  -- 更新ユーザーID
  updated_user_id varchar(30) NOT NULL,
  -- 更新日時
  updated_date_time datetime NOT NULL,
  PRIMARY KEY (pk)
);


-- ユーザマスタ : Shimetocoにログインするために利用するユーザテーブル。
-- 連携ユーザマスタの情報を基にレコードを生成する。
CREATE TABLE m_user
(
  -- PK
  pk bigint NOT NULL,
  -- ユーザID : ログインに利用するユーザのID。
  --
  user_id varchar(30) NOT NULL UNIQUE,
  -- ユーザ名 : ユーザー名。
  -- mitocoではvarchar(150)
  user_name varchar(150),
  -- パスワード : ログインに利用するパスワード。
  -- mitocoではvarchar(20)。
  password varchar(20) NOT NULL,
  -- バージョン
  version_no bigint NOT NULL,
  -- 作成ユーザーID
  created_user_id varchar(30) NOT NULL,
  -- 作成日時
  created_date_time datetime NOT NULL,
  -- 更新ユーザーID
  updated_user_id varchar(30) NOT NULL,
  -- 更新日時
  updated_date_time datetime NOT NULL,
  PRIMARY KEY (pk)
);


-- ユーザ・ロール関連 : ユーザとロールN:N関連を表現するテーブル。
CREATE TABLE r_user_role
(
  -- PK
  pk bigint NOT NULL,
  -- ユーザPK
  user_pk bigint NOT NULL,
  -- ロールPK
  role_pk bigint NOT NULL,
  -- バージョン
  version_no bigint NOT NULL,
  -- 作成ユーザーID
  created_user_id varchar(30) NOT NULL,
  -- 作成日時
  created_date_time datetime NOT NULL,
  -- 更新ユーザーID
  updated_user_id varchar(30) NOT NULL,
  -- 更新日時
  updated_date_time datetime NOT NULL,
  PRIMARY KEY (pk)
);



/* Create Foreign Keys */

ALTER TABLE r_user_role
  ADD FOREIGN KEY (role_pk)
  REFERENCES m_role (pk)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
;


ALTER TABLE r_user_role
  ADD FOREIGN KEY (user_pk)
  REFERENCES m_user (pk)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
;



