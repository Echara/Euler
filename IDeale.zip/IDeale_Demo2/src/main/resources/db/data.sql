-- ロールマスタ
INSERT INTO m_role (pk, key_value, display_name, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('1', 'キー_1', '表示名_1', '1', '作成ユーザーID_1', '2000-01-01 12:00:00.000', '更新ユーザーID_1', '2000-01-01 12:00:00.000');
INSERT INTO m_role (pk, key_value, display_name, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('2', 'キー_2', '表示名_2', '2', '作成ユーザーID_2', '2000-01-02 12:00:00.000', '更新ユーザーID_2', '2000-01-02 12:00:00.000');
INSERT INTO m_role (pk, key_value, display_name, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('3', 'キー_3', '表示名_3', '3', '作成ユーザーID_3', '2000-01-03 12:00:00.000', '更新ユーザーID_3', '2000-01-03 12:00:00.000');
INSERT INTO m_role (pk, key_value, display_name, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('4', 'キー_4', '表示名_4', '4', '作成ユーザーID_4', '2000-01-04 12:00:00.000', '更新ユーザーID_4', '2000-01-04 12:00:00.000');
INSERT INTO m_role (pk, key_value, display_name, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('5', 'キー_5', '表示名_5', '5', '作成ユーザーID_5', '2000-01-05 12:00:00.000', '更新ユーザーID_5', '2000-01-05 12:00:00.000');


-- ユーザマスタ
INSERT INTO m_user (pk, user_id, user_name, password, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('1', 'user1', 'ユーザ名_1', 'password1', '1', '作成ユーザーID_1', '2000-01-01 12:00:00.000', '更新ユーザーID_1', '2000-01-01 12:00:00.000');
INSERT INTO m_user (pk, user_id, user_name, password, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('2', 'user2', 'ユーザ名_2', 'password2', '2', '作成ユーザーID_2', '2000-01-02 12:00:00.000', '更新ユーザーID_2', '2000-01-02 12:00:00.000');
INSERT INTO m_user (pk, user_id, user_name, password, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('3', 'user3', 'ユーザ名_3', 'password3', '3', '作成ユーザーID_3', '2000-01-03 12:00:00.000', '更新ユーザーID_3', '2000-01-03 12:00:00.000');
INSERT INTO m_user (pk, user_id, user_name, password, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('4', 'user4', 'ユーザ名_4', 'password4', '4', '作成ユーザーID_4', '2000-01-04 12:00:00.000', '更新ユーザーID_4', '2000-01-04 12:00:00.000');
INSERT INTO m_user (pk, user_id, user_name, password, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('5', 'user5', 'ユーザ名_5', 'password5', '5', '作成ユーザーID_5', '2000-01-05 12:00:00.000', '更新ユーザーID_5', '2000-01-05 12:00:00.000');


-- ユーザ・ロール関連
INSERT INTO r_user_role (pk, user_pk, role_pk, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('1', '1', '1', '1', '作成ユーザーID_1', '2000-01-01 12:00:00.000', '更新ユーザーID_1', '2000-01-01 12:00:00.000');
INSERT INTO r_user_role (pk, user_pk, role_pk, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('2', '2', '2', '2', '作成ユーザーID_2', '2000-01-02 12:00:00.000', '更新ユーザーID_2', '2000-01-02 12:00:00.000');
INSERT INTO r_user_role (pk, user_pk, role_pk, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('3', '3', '3', '3', '作成ユーザーID_3', '2000-01-03 12:00:00.000', '更新ユーザーID_3', '2000-01-03 12:00:00.000');
INSERT INTO r_user_role (pk, user_pk, role_pk, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('4', '4', '4', '4', '作成ユーザーID_4', '2000-01-04 12:00:00.000', '更新ユーザーID_4', '2000-01-04 12:00:00.000');
INSERT INTO r_user_role (pk, user_pk, role_pk, version_no, created_user_id, created_date_time, updated_user_id, updated_date_time) VALUES ('5', '5', '5', '5', '作成ユーザーID_5', '2000-01-05 12:00:00.000', '更新ユーザーID_5', '2000-01-05 12:00:00.000');


