package com.ck.spring.aop;

import org.springframework.stereotype.Component;

@Component
public class SmartDog implements SmartAnimalable{

	@Override
	public float getSum(float i, float j) {
		// TODO 自動生成されたメソッド・スタブ
		float result = i + j;
		System.out.println("result is : " + result);
		return result;
	}

	@Override
	public float getSub(float i, float j) {
		// TODO 自動生成されたメソッド・スタブ
		float result = i - j;
		System.out.println("result is : " + result);
		return result;
	}

}
