package com.ck.spring.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SmartAspect {

/*	 @Before(value = "execution(public float com.ck.spring.aop.SmartDog.*(..))")
	public void showStartLog(JoinPoint joinPoint) {
		Signature signature = joinPoint.getSignature();
		String name = signature.getName();
		Object[] args = joinPoint.getArgs();

		System.out.println("here is Before, " + "name is: " + name + " ,args is: " + Arrays.asList(args));
	}

	 @AfterReturning(value = "execution(public float com.ck.spring.aop.SmartDog.getSum(float, float))",returning = "abc")
	 public void showSuccessLog(JoinPoint joinPoint,Object abc) {
		 System.out.println("here is AfterReturning, result is: " + abc);
	 }

	 @AfterThrowing(value = "execution(public float com.ck.spring.aop.SmartDog.getSum(float, float))",throwing = "t")
	 public void showExceptionLog(JoinPoint joinPoint,Throwable t) {
		 System.out.println("here is AfterThrowing, info: " + t);
	 }

	 @After(value = "execution(public float com.ck.spring.aop.SmartDog.getSum(float, float))")
	 public void showFinallyLog() {
		 System.out.println("here is After");
	 }*/

	 @Around(value = "execution(* *.*(..))")
	 public Object doAround(ProceedingJoinPoint joinPoint) {

		Object result = null;
		Signature signature = joinPoint.getSignature();
		String name = signature.getName();
		Object[] args = joinPoint.getArgs();

		 try {
			System.out.println("here is Before, " + "name is: " + name + " ,args is: " + Arrays.asList(args));

			result = joinPoint.proceed();
			System.out.println("here is AfterReturning, result is: " + result);
		 }catch (Throwable e) {
			// TODO: handle exception
			System.out.println("here is AfterThrowing, info: " + e);
		}finally {
			System.out.println("here is After");
		}

		 return result;

	 }
}
