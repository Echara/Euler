package com.ck.spring.aop;

public interface SampleInterface {

	void hello();
}
