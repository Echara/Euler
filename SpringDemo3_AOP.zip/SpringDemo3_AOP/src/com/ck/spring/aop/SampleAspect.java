package com.ck.spring.aop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SampleAspect {

	@Before(value = "execution(public void com.ck.spring.aop.SampleClass.hello())")
	public void showStartLog() {
		System.out.println("before");
	}
}
