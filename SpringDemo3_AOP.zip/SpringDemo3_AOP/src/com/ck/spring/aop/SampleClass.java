package com.ck.spring.aop;

import org.springframework.stereotype.Component;

@Component
public class SampleClass implements SampleInterface{

	public void hello() {
	}

}
