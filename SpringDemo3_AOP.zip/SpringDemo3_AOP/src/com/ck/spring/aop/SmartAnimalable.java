package com.ck.spring.aop;

public interface SmartAnimalable {

	float getSum(float i,float j);
	float getSub(float i,float j);

}
