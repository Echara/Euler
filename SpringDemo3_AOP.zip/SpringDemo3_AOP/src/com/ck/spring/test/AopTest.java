package com.ck.spring.test;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AopTest {

	ApplicationContext applicationContext;

	@Before
	public void init() {
		applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
	}

	@Test
	public void testv01() {

/*		SmartAnimalable smartAnimalable = applicationContext.getBean(SmartAnimalable.class);
		smartAnimalable.getSum(1f, 1f);
		smartAnimalable.getSub(2f, 2.5f);*/

/*		SmartDog smartDog = applicationContext.getBean(SmartDog.class);
		smartDog.getSum(1f, 1f);*/


		//applicationContext.getBean("sampleClass");
		System.out.println(Arrays.asList(applicationContext.getBeanDefinitionNames()));
		applicationContext.getBean("sampleClass");
	}

}
