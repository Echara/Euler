package com.spring.test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ioc.component.MyComponent;
import com.ioc.component.OrderAction;
import com.ioc.component.OrderDao;
import com.ioc.component.OrderService;

public class IocTest {

	private ApplicationContext applicationContext;

	@Before
	public void init() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
	}

	@Test
	public void test01() {
		MyComponent mc = (MyComponent) applicationContext.getBean("hahaha");
		MyComponent mc2 = (MyComponent) applicationContext.getBean("myComponent2");
		OrderAction oa = (OrderAction) applicationContext.getBean(OrderAction.class);
		OrderService os = (OrderService) applicationContext.getBean(OrderService.class);
		OrderDao od = (OrderDao) applicationContext.getBean(OrderDao.class);
		System.out.println(mc + "\t" + mc2);
		System.out.println(oa);
		System.out.println(os);
		System.out.println(od);
	}

}
