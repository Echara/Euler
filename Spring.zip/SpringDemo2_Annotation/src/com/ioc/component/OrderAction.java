package com.ioc.component;

import org.springframework.stereotype.Controller;

@Controller
public class OrderAction {

}
