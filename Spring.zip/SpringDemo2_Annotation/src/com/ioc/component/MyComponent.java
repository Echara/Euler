package com.ioc.component;

import org.springframework.stereotype.Component;

@Component(value="hahaha")
public class MyComponent {

}
