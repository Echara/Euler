package com.ck.spring.bean;

public class Order {

	private Integer id;
	private String snOrder;
	private Integer totalPrice;
	private String pay;
	private static Integer i;

	public  Integer getI() {
		return i;
	}
	public void setI(Integer i) {
		Order.i = i;
	}

	public Order(Integer id, String snOrder, Integer totalPrice, String pay) {
		super();
		this.id = id;
		this.snOrder = snOrder;
		this.totalPrice = totalPrice;
		this.pay = pay;
	}
	public Order() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSnOrder() {
		return snOrder;
	}
	public void setSnOrder(String snOrder) {
		this.snOrder = snOrder;
	}
	public Integer getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getPay() {
		return pay;
	}
	public void setPay(String pay) {
		this.pay = pay;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", snOrder=" + snOrder + ", totalPrice=" + totalPrice + ", pay=" + pay + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((pay == null) ? 0 : pay.hashCode());
		result = prime * result + ((snOrder == null) ? 0 : snOrder.hashCode());
		result = prime * result + ((totalPrice == null) ? 0 : totalPrice.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (pay == null) {
			if (other.pay != null)
				return false;
		} else if (!pay.equals(other.pay))
			return false;
		if (snOrder == null) {
			if (other.snOrder != null)
				return false;
		} else if (!snOrder.equals(other.snOrder))
			return false;
		if (totalPrice == null) {
			if (other.totalPrice != null)
				return false;
		} else if (!totalPrice.equals(other.totalPrice))
			return false;
		return true;
	}

}
