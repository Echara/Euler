package com.ck.spring.bean;

public class Member {

	private Integer id;
	private String name;
	private String job;
	private Order order;
	public Member(Integer id, String name, String job, Order order) {
		super();
		this.id = id;
		this.name = name;
		this.job = job;
		this.order = order;
	}
	public Member() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", job=" + job + ", order=" + order + "]";
	}


}
