package com.ck.spring.bean;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.FactoryBean;

public class OrderFactoryBean implements FactoryBean<Order> {

	private List<Member_withFiled> list;
	private Integer key1;
	private Integer key2;
	private Integer i;

	{
		list = new ArrayList<Member_withFiled>();
		list.add(new Member_withFiled());
		list.add(new Member_withFiled());

		List<Order> list_1 = new ArrayList<Order>();
		list_1.add(new Order(901,null,null,null));
		list_1.add(new Order(902,null,null,null));
		List<Order> list_2 = new ArrayList<Order>();
		list_2.add(new Order(903,null,null,null));
		list_2.add(new Order(904,null,null,null));

		list.get(0).setList(list_1);
		list.get(1).setList(list_2);
	}



	public Integer getKey1() {
		return key1;
	}

	public void setKey1(Integer key1) {
		this.key1 = key1;
	}

	public Integer getKey2() {
		return key2;
	}

	public void setKey2(Integer key2) {
		this.key2 = key2;
	}

	public Integer getI() {
		return i;
	}

	public void setI(Integer i) {
		this.i = i;
	}

	@Override
	public Order getObject() throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		return list.get(getKey1()).getList().get(getKey2());
	}

	@Override
	public Class<?> getObjectType() {
		// TODO 自動生成されたメソッド・スタブ
		return Order.class;
	}

	@Override
	public boolean isSingleton() {
		// TODO 自動生成されたメソッド・スタブ
		return true;
		//return false
	}





}
