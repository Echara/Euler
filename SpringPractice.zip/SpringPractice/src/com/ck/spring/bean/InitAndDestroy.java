package com.ck.spring.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class InitAndDestroy implements BeanPostProcessor {

	private static String flag;

	public InitAndDestroy() {
		super();
		flag = "constructed";
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public static String getFlag() {
		return flag;
	}

	public void init() {
		flag = "initialized";
		System.out.println("initialized");
	}
	public void des() {
		flag = "closed";
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("before");
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("After");
		return bean;
	}


}
