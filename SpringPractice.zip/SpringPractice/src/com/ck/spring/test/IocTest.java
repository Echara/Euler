package com.ck.spring.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ck.spring.bean.InitAndDestroy;
import com.ck.spring.bean.Member;
import com.ck.spring.bean.Member_withFiled;
import com.ck.spring.bean.Order;

public class IocTest {

	private ApplicationContext applicationContext;

	@Before
	public void initialize() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
	}

	@Test
	public void test01() {
		Order order = (Order) applicationContext.getBean("order1");
		assertEquals(1, (int)order.getId());
		assertEquals("75849285", order.getSnOrder());
		assertEquals(10000, (int)order.getTotalPrice());
		assertEquals("cash", order.getPay());
	}

	@Test
	public void test02() {
		Order order = (Order) applicationContext.getBean("order2");
		assertEquals(2, (int)order.getId());
		assertEquals("95870175", order.getSnOrder());
		assertEquals(20000, (int)order.getTotalPrice());
		assertEquals("card", order.getPay());
	}

	@Test
	public void test03() {
		Order order = (Order) applicationContext.getBean("order3");
		assertEquals(3, (int)order.getId());
		assertEquals("73810597", order.getSnOrder());
		assertEquals(35000, (int)order.getTotalPrice());
		assertEquals("shop", order.getPay());
	}

	@Test
	public void test04() {
		Member member = (Member) applicationContext.getBean("menber1");
		assertEquals(1, (int)member.getId());
		assertEquals("Tom", member.getName());
		assertEquals("salesman", member.getJob());
		assertEquals(applicationContext.getBean("order1"), member.getOrder());
	}

	@Test
	public void test05() {
		Member member = (Member) applicationContext.getBean("menber2");
		assertEquals(2, (int)member.getId());
		assertEquals("Jerry", member.getName());
		assertEquals("developer", member.getJob());

		assertEquals(999, (int)member.getOrder().getId());
		assertEquals("92486013", member.getOrder().getSnOrder());
		assertEquals(500, (int)member.getOrder().getTotalPrice());
		assertEquals("shop", member.getOrder().getPay());
	}

	@Test
	public void test06() {
		Member_withFiled member = (Member_withFiled) applicationContext.getBean("menber3");
		assertEquals(1, (int)member.getList().get(0).getId());
		assertEquals("75849285", member.getList().get(0).getSnOrder());
		assertEquals(10000, (int)member.getList().get(0).getTotalPrice());
		assertEquals("cash", member.getList().get(0).getPay());

		assertEquals(998, (int)member.getList().get(1).getId());
		assertEquals("98476576154", member.getList().get(1).getSnOrder());
		assertEquals(680, (int)member.getList().get(1).getTotalPrice());
		assertEquals("cash", member.getList().get(1).getPay());
	}

	@Test
	public void test07() {
		Member_withFiled member = (Member_withFiled) applicationContext.getBean("menber4");
		assertEquals(1, (int)member.getMap().get("first").getId());
		assertEquals("75849285", member.getMap().get("first").getSnOrder());
		assertEquals(10000, (int)member.getMap().get("first").getTotalPrice());
		assertEquals("cash", member.getMap().get("first").getPay());

		assertEquals(997, (int)member.getMap().get("second").getId());
		assertEquals("09879624", member.getMap().get("second").getSnOrder());
		assertEquals(1100, (int)member.getMap().get("second").getTotalPrice());
		assertEquals("card", member.getMap().get("second").getPay());
	}

	@Test
	public void test08() {
		Member_withFiled member = (Member_withFiled) applicationContext.getBean("member5");
		assertEquals("hello", member.getProperties().get("first"));
		assertEquals("world", member.getProperties().get("second"));
	}

	@Test
	public void test09(){
		List<Order> list = (List<Order>) applicationContext.getBean("list1");
		Order order1 = (Order)applicationContext.getBean("order1");
		Order order2 = (Order)applicationContext.getBean("order2");
		assertEquals(order1.getId(), list.get(0).getId());
		assertEquals(order2.getId(), list.get(1).getId());
	}

	@Test
	public void test10(){
		Member member = (Member) applicationContext.getBean("member6");
		assertEquals(6,(int)member.getId());
		assertEquals(996,(int)member.getOrder().getId());
	}

	@Test
	public void test11(){
		Order order = (Order) applicationContext.getBean("member_static");
		assertEquals(940,(int)order.getId());
		assertEquals("814981876991",order.getSnOrder());
		assertEquals(40000,(int)order.getTotalPrice());
		assertEquals("card",order.getPay());
	}

	@Test
	public void test12() {
		Order order = (Order) applicationContext.getBean("OrderOfIns");
		assertEquals(940,(int)order.getId());
		assertEquals("814981876991",order.getSnOrder());
		assertEquals(40000,(int)order.getTotalPrice());
		assertEquals("card",order.getPay());
	}

	@Test
	public void test13() {
		Order order = (Order) applicationContext.getBean("factory");
		assertEquals(903,(int)order.getId());
		assertEquals(null,order.getSnOrder());
		assertEquals(null,order.getTotalPrice());
		assertEquals(null,order.getPay());
	}

	@Test
	public void test14() {
		Order order = (Order) applicationContext.getBean("order5");
		assertEquals(1, (int)order.getId());
		assertEquals("58496295717", order.getSnOrder());
		assertEquals(10000, (int)order.getTotalPrice());
		assertEquals("cash", order.getPay());
	}

	@Test
	public void test15() {
		Order order = (Order) applicationContext.getBean("order7");
		assertEquals(6, (int)order.getI());
	}

	@Test
	public void test15_1() {
		Order order = (Order) applicationContext.getBean("order6.1");
		assertEquals(7, (int)order.getId());

	}

	@Test
	public void test16() {
		Order order1 = (Order) applicationContext.getBean("order8");
		Order order2 = (Order) applicationContext.getBean("order8");
		Order order3 = (Order) applicationContext.getBean("order9");
		Order order4 = (Order) applicationContext.getBean("order9");
		assertTrue(order1==order2);
		assertFalse(order3==order4);
	}

	@Test
	public void test17_18() {
		InitAndDestroy id = (InitAndDestroy) applicationContext.getBean("i_and_d");
		assertEquals("initialized", InitAndDestroy.getFlag());

		ConfigurableApplicationContext cac = (ConfigurableApplicationContext) applicationContext;
		cac.close();
		assertEquals("closed", InitAndDestroy.getFlag());

	}
}
