package com.ck.spring.bean;

import java.util.HashMap;

public class MyInstanceFactory {

	private HashMap<String,Monster> map;

	{
		map = new HashMap<String,Monster>();
		map.put("monsterKey01", new Monster(800,"~~fish~~","skill_8"));
		map.put("monsterKey02", new Monster(900,"~~bird~~","skill_9"));
	}

	public Monster getMonster(String key) {
		return map.get(key);
	}

}
