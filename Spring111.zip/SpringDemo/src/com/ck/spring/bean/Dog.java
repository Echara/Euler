package com.ck.spring.bean;

public class Dog {

	private String name;

	public Dog(String name) {
		super();
		this.name = name;
	}

	public Dog() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
