package com.ck.spring.bean;

public class Cat {

	private String name;



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public  Cat() {
		System.out.println("Cat was born");
	}

	public Cat(String name) {
		super();
		this.name = name;
	}

	public void init() {
		System.out.println("Cat was initialized and its name is " + this.name);
	}

	public void play() {
		System.out.println(this.name + " is playing");
	}

	public void des() {
		System.out.println(this.name + " was dead");
	}


}
