package com.ck.spring.bean;

public class Monster {

	private Integer id;
	private String nickname;
	private String skill;

	public Monster() {
		System.out.println("created");
	}

	public Monster(Integer id, String nickname, String skill) {
		super();
		this.id = id;
		this.nickname = nickname;
		this.skill = skill;
	}


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}

	@Override
	public String toString() {
		return "Monster [id=" + id + ", nickname=" + nickname + ", skill=" + skill + "]";
	}

}
