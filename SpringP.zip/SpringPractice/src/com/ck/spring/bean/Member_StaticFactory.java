package com.ck.spring.bean;

import java.util.ArrayList;
import java.util.List;

public class Member_StaticFactory extends Member{

	private static List<Order> list;

	static {
		list = new ArrayList<Order>();
		list.add(new Order(950,"7658395871",50000,"cash"));
		list.add(new Order(940,"814981876991",40000,"card"));
	}

	public static Order get(int index) {
		return list.get(index);
	}
}
