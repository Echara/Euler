package com.ck.spring.bean;

import java.util.ArrayList;
import java.util.List;

public class Member_InstanceFactory extends Member {

	private List<Order> list;

	{	list = new ArrayList<Order>();
		list.add(new Order(950,"7658395871",50000,"cash"));
		list.add(new Order(940,"814981876991",40000,"card"));
	}

	public Order get(int index) {
		return list.get(index);
	}

}
