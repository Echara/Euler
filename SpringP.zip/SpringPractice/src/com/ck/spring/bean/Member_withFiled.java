package com.ck.spring.bean;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Member_withFiled extends Member{

	Map<String,Order> map;
	List<Order> list;
	Properties properties;
	public Member_withFiled(Integer id, String name, String job, Order order, Map<String, Order> map, List<Order> list,
			Properties properties) {
		super(id, name, job, order);
		this.map = map;
		this.list = list;
		this.properties = properties;
	}
	public Member_withFiled() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public Member_withFiled(Integer id, String name, String job, Order order) {
		super(id, name, job, order);
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public Map<String, Order> getMap() {
		return map;
	}
	public void setMap(Map<String, Order> map) {
		this.map = map;
	}
	public List<Order> getList() {
		return list;
	}
	public void setList(List<Order> list) {
		this.list = list;
	}
	public Properties getProperties() {
		return properties;
	}
	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	@Override
	public String toString() {
		return "Menber_withFiled [map=" + map + ", list=" + list + ", properties=" + properties + "]";
	}



}
