package com.ck.spring.bean;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.FactoryBean;

public class MyFactoryBean implements FactoryBean<Monster> {

	private String keyVal;
	private Map<String,Monster> map;

	{
		map = new HashMap<String,Monster>();
		map.put("monsterKey01", new Monster(1000,"~~Big_Fish~~","skill_10"));
		map.put("monsterKey02", new Monster(1100,"~~Big_Bird~~","skill_11"));
	}


	public void setKeyVal(String keyval) {
		this.keyVal = keyval;
	}

	@Override
	public Monster getObject() throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		return map.get(keyVal);
	}

	@Override
	public Class<?> getObjectType() {
		// TODO 自動生成されたメソッド・スタブ
		return Monster.class;
	}

	public boolean isSingleton() {
		return true;
	}

}
