package com.ck.spring.bean;

public class SpELBean {

	private String beanName;
	private String monsterName;
	private Monster monster;
	private Double result;
	private String bookName;
	public SpELBean() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public String getBeanName() {
		return beanName;
	}
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	public String getMonsterName() {
		return monsterName;
	}
	public void setMonsterName(String monsterName) {
		this.monsterName = monsterName;
	}
	public Monster getMonster() {
		return monster;
	}
	public void setMonster(Monster monster) {
		this.monster = monster;
	}
	public Double getResult() {
		return result;
	}
	public void setResult(Double result) {
		this.result = result;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public Double getSum(double n1 , double n2) {
		return n1+n2;
	}

	public static String readBook(String bookname) {
		return "your book is :" + bookname;
	}

}
