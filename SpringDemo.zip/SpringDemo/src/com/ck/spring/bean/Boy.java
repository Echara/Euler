package com.ck.spring.bean;

public class Boy {

	private String name;
	private Dog dog;
	public Boy(String name, Dog dog) {
		super();
		this.name = name;
		this.dog = dog;
	}
	public Boy() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Dog getDog() {
		return dog;
	}
	public void setDog(Dog dog) {
		this.dog = dog;
	}



}
