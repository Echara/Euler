package com.ck.spring.bean;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Master {

	private String name;
	private Monster monster;
	private Monster monster2;
	private List<Monster> monsterList;
	private Map<String,Monster> monsterMap;
	private Properties ps;


	public Properties getPs() {
		return ps;
	}

	public void setPs(Properties ps) {
		this.ps = ps;
	}

	public Map<String, Monster> getMonsterMap() {
		return monsterMap;
	}

	public void setMonsterMap(Map<String, Monster> monsterMap) {
		this.monsterMap = monsterMap;
	}

	public List<Monster> getMonsterList() {
		return monsterList;
	}

	public void setMonsterList(List<Monster> monsterList) {
		this.monsterList = monsterList;
	}

	public Monster getMonster2() {
		return monster2;
	}

	public void setMonster2(Monster monster2) {
		this.monster2 = monster2;
	}

	public Master() {
		super();
	}

	public Master(String name, Monster monster) {
		super();
		this.name = name;
		this.monster = monster;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Monster getMonster() {
		return monster;
	}

	public void setMonster(Monster monster) {
		this.monster = monster;
	}

	@Override
	public String toString() {
		return "Master [name=" + name + ", monster=" + monster + ", monster2=" + monster2 +  "]";
	}


}
