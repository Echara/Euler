package com.ck.spring.bean;

import java.util.HashMap;

public class MyStaticFactory {

	private static HashMap<String,Monster> map;

	static{
		map = new HashMap<String,Monster>();
		map.put("monsterKey01", new Monster(600,"fish","skill_6"));
		map.put("monsterKey02", new Monster(700,"bird","skill_7"));
	}

	public static Monster getMonster(String key) {
		return map.get(key);
	}

}
