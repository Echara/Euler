package com.ck.spring.test;


import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ck.spring.bean.Boy;
import com.ck.spring.bean.Cat;
import com.ck.spring.bean.Master;
import com.ck.spring.bean.Monster;
import com.ck.spring.bean.SpELBean;

class IocTest {

	private ApplicationContext applicationContext;

/*	@Before
	public void initialize() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
	}

*/


	@Test
	public void test01() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Object bean = applicationContext.getBean("monster01");
		System.out.println("bean" + bean);
	}

/*
	@Test
	public void test01_1() {
		Object bean = applicationContext.getBean(Monster.class);
		System.out.println("bean" + bean);
	}
*/

	@Test
	public void test02() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Object bean = applicationContext.getBean("monster02");
		System.out.println("bean" + bean);
	}

	@Test
	public void test03() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Object bean = applicationContext.getBean("monster03");
		System.out.println("bean" + bean);
	}

	@Test
	public void test04() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster bean = (Monster)applicationContext.getBean("monster04");
		//System.out.println("bean" + bean);
		assertEquals("skill_4", bean.getSkill());
	}

	@Test
	public void testM01() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Master master = (Master)applicationContext.getBean("master01");
		System.out.println("Master" + master);
	}

	@Test
	public void testM02() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Master master = (Master) applicationContext.getBean("master02");
		System.out.println("Master" + master);
	}

	@Test
	public void testM03() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Master master = (Master) applicationContext.getBean("master03");
		//System.out.println("Master" + master);
		List<Monster> list = master.getMonsterList();
		for(Monster m:list)
			System.out.println("monster:"+m);
	}

	@Test
	public void testM04() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Master master = (Master) applicationContext.getBean("master04");
		Map<String,Monster> map = master.getMonsterMap();
		for(Map.Entry<String, Monster> e:map.entrySet()) {
			System.out.println("NO:"+e.getKey());
			System.out.println("monster:"+e.getValue());
		}
	}

	@Test
	public void testM05() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Master master = (Master) applicationContext.getBean("master05");
		Properties ps = master.getPs();
		for(String key:ps.stringPropertyNames()) {
			System.out.println("Key:"+key);
			System.out.println("Value:"+ps.getProperty(key));
		}
	}

	@Test
	public void testH01() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		List<String> list = (List) applicationContext.getBean("myList");
		for(String value:list) {
			System.out.println("value:"+value);
		}
	}

	@Test
	public void testH02() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Boy boy = (Boy) applicationContext.getBean("myBoy");
		System.out.println("boy:"+boy.getName());
		System.out.println("dog:"+boy.getDog().getName());
	}

	@Test
	public void testH03() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster) applicationContext.getBean("myMonster01");
		System.out.println(monster);
	}

	@Test
	public void testH04() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster) applicationContext.getBean("myMonster02");
		System.out.println(monster);
	}

	@Test
	public void testH05() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster) applicationContext.getBean("myMonster03");
		System.out.println(monster);
	}

	@Test
	public void test06() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster)applicationContext.getBean("monster06");
		System.out.println(monster);
	}

	@Test
	public void test07() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster)applicationContext.getBean("monster071");
		System.out.println(monster);
	}


	@Test
	public void test08() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster1 = (Monster)applicationContext.getBean("monster071");
		Monster monster2 = (Monster)applicationContext.getBean("monster071");
		System.out.println(monster1.hashCode());
		System.out.println(monster2.hashCode());
		assertEquals(monster1.hashCode(), monster2.hashCode());

		Monster monster3 = (Monster)applicationContext.getBean("monster08");
		Monster monster4 = (Monster)applicationContext.getBean("monster08");
		System.out.println(monster3.hashCode());
		System.out.println(monster4.hashCode());
		assertNotEquals(monster3.hashCode(), monster4.hashCode());
	}

	@Test
	public void testH06() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Cat cat = (Cat)applicationContext.getBean("cat");
		cat.play();
		ConfigurableApplicationContext cac = (ConfigurableApplicationContext) applicationContext;
		cac.close();
	}

	@Test
	public void testH07() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("BeanPostProcessorTest");
	}

	@Test
	public void test09() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		Monster monster = (Monster)applicationContext.getBean("monster12");
		System.out.println(monster);
	}

	@Test
	public void testH08() {
		applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		SpELBean spel = (SpELBean)applicationContext.getBean("spelBean");
		System.out.println("---------------------------------");
		System.out.println("name= " + spel.getBeanName());
		System.out.println("monsterName= " + spel.getMonsterName());
		System.out.println("monster= " + spel.getMonster());
		System.out.println("result= " + spel.getResult());
		System.out.println("bookname= " + spel.getBookName());

	}

}
