package a;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class P implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("after");
		return bean;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		// TODO 自動生成されたメソッド・スタブ
		System.out.println("before");
		return bean;
	}

	public P() {
		super();
		System.out.println("P");
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public void init() {
		System.out.println("P_init");
	}


}
