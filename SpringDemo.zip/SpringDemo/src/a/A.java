package a;

public class A {

	public A() {
		super();
		System.out.println("A");
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public void init() {
		System.out.println("A_init");
	}
}
