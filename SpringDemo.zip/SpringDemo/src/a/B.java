package a;

public class B {
	public B() {
		super();
		System.out.println("B");
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public void bbbbb() {
		System.out.println("B_init");
	}
}
